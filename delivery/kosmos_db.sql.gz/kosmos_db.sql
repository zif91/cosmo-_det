/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: kosmos
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `evo_active_user_locks`
--

DROP TABLE IF EXISTS `evo_active_user_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_active_user_locks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` varchar(32) NOT NULL DEFAULT '',
  `internalKey` int(11) NOT NULL DEFAULT 0,
  `elementType` int(11) NOT NULL DEFAULT 0,
  `elementId` int(11) NOT NULL DEFAULT 0,
  `lasthit` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_element_id` (`elementType`,`elementId`,`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_active_user_locks`
--

LOCK TABLES `evo_active_user_locks` WRITE;
/*!40000 ALTER TABLE `evo_active_user_locks` DISABLE KEYS */;
INSERT INTO `evo_active_user_locks` VALUES
(1,'qimvq9mrig3mud84tad3puqcqr',1,7,2,1781187584),
(2,'qimvq9mrig3mud84tad3puqcqr',1,7,1,1781187600);
/*!40000 ALTER TABLE `evo_active_user_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_active_user_sessions`
--

DROP TABLE IF EXISTS `evo_active_user_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_active_user_sessions` (
  `sid` varchar(32) NOT NULL DEFAULT '',
  `internalKey` int(11) NOT NULL DEFAULT 0,
  `lasthit` int(11) NOT NULL DEFAULT 0,
  `ip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_active_user_sessions`
--

LOCK TABLES `evo_active_user_sessions` WRITE;
/*!40000 ALTER TABLE `evo_active_user_sessions` DISABLE KEYS */;
INSERT INTO `evo_active_user_sessions` VALUES
('qimvq9mrig3mud84tad3puqcqr',1,1781187600,'188.246.181.88');
/*!40000 ALTER TABLE `evo_active_user_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_active_users`
--

DROP TABLE IF EXISTS `evo_active_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_active_users` (
  `sid` varchar(32) NOT NULL DEFAULT '',
  `internalKey` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `lasthit` int(11) NOT NULL DEFAULT 0,
  `action` varchar(10) NOT NULL DEFAULT '',
  `id` int(11) DEFAULT NULL,
  PRIMARY KEY (`sid`,`internalKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_active_users`
--

LOCK TABLES `evo_active_users` WRITE;
/*!40000 ALTER TABLE `evo_active_users` DISABLE KEYS */;
INSERT INTO `evo_active_users` VALUES
('qimvq9mrig3mud84tad3puqcqr',1,'admin',1781187600,'27',1);
/*!40000 ALTER TABLE `evo_active_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_categories`
--

DROP TABLE IF EXISTS `evo_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(45) NOT NULL DEFAULT '',
  `rank` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_categories`
--

LOCK TABLES `evo_categories` WRITE;
/*!40000 ALTER TABLE `evo_categories` DISABLE KEYS */;
INSERT INTO `evo_categories` VALUES
(1,'Manager and Admin',0),
(2,'Kosmos Site',1),
(3,'SEO',2);
/*!40000 ALTER TABLE `evo_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_document_groups`
--

DROP TABLE IF EXISTS `evo_document_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_document_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_group` int(11) NOT NULL DEFAULT 0,
  `document` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_dg_id` (`document_group`,`document`),
  KEY `document_group` (`document_group`),
  KEY `document` (`document`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_document_groups`
--

LOCK TABLES `evo_document_groups` WRITE;
/*!40000 ALTER TABLE `evo_document_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `evo_document_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_documentgroup_names`
--

DROP TABLE IF EXISTS `evo_documentgroup_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_documentgroup_names` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(245) NOT NULL DEFAULT '',
  `private_memgroup` int(11) DEFAULT 0 COMMENT 'determine whether the document group is private to manager users',
  `private_webgroup` int(11) DEFAULT 0 COMMENT 'determines whether the document is private to web users',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_documentgroup_names`
--

LOCK TABLES `evo_documentgroup_names` WRITE;
/*!40000 ALTER TABLE `evo_documentgroup_names` DISABLE KEYS */;
/*!40000 ALTER TABLE `evo_documentgroup_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_event_log`
--

DROP TABLE IF EXISTS `evo_event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_event_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eventid` int(11) DEFAULT 0,
  `createdon` int(11) NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 1 COMMENT '1- information, 2 - warning, 3- error',
  `user` int(11) NOT NULL DEFAULT 0 COMMENT 'link to user table',
  `usertype` int(11) NOT NULL DEFAULT 0 COMMENT '0 - manager, 1 - web',
  `source` varchar(50) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_log_user_index` (`user`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_event_log`
--

LOCK TABLES `evo_event_log` WRITE;
/*!40000 ALTER TABLE `evo_event_log` DISABLE KEYS */;
INSERT INTO `evo_event_log` VALUES
(1,0,1781103178,3,0,1,'Parser','EvolutionCMS\\Main\\Controllers\\BaseController not exists!'),
(2,0,1781103274,3,0,1,'Parser','EvolutionCMS\\Main\\Controllers\\BaseController not exists!'),
(3,0,1781103274,3,0,1,'Parser','EvolutionCMS\\Main\\Controllers\\BaseController not exists!'),
(4,0,1781103274,3,0,1,'Parser','EvolutionCMS\\Main\\Controllers\\BaseController not exists!'),
(5,0,1781103274,3,0,1,'Parser','EvolutionCMS\\Main\\Controllers\\BaseController not exists!'),
(6,0,1781103274,3,0,1,'Parser','EvolutionCMS\\Main\\Controllers\\BaseController not exists!'),
(7,0,1781103274,3,0,1,'Parser','EvolutionCMS\\Main\\Controllers\\BaseController not exists!'),
(8,0,1781103386,3,0,1,'Parser','EvolutionCMS\\Main\\Controllers\\BaseController not exists!'),
(9,0,1781103432,3,0,1,'Parser','EvolutionCMS\\Main\\Controllers\\BaseController not exists!'),
(10,0,1781103470,3,0,1,'Parser','EvolutionCMS\\Main\\Controllers\\BaseController not exists!'),
(11,0,1781103635,3,0,1,'Parser -     $result = (new LeadService())-&gt;han','<h2 style=\"color:red\">&laquo; Evolution CMS Parse Error &raquo;</h2><h3 style=\"color:red\">Class \"EvolutionCMS\\Main\\Services\\LeadService\" not found</h3>\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>File</td>\n		<td>/var/www/kosmos/core/custom/routes.php</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Line</td>\n		<td>9</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Source</td>\n		<td>    $result = (new LeadService())-&gt;handle($request-&gt;all());\n</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>REQUEST_URI</td>\n		<td>http://localhost/api/lead</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Referer</td>\n		<td></td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>User Agent</td>\n		<td>Mozilla/5.0</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>IP</td>\n		<td>127.0.0.1</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Current time</td>\n		<td>2026-06-10 15:00:35</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>MySQL</td>\n		<td>0.0000 s (0 Requests)</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>PHP</td>\n		<td>0.0144 s</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Total</td>\n		<td>0.0144 s</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Memory</td>\n		<td>1.6594467163086 mb</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Core->processRoutes</strong>()<br />index.php on line 137</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatch</strong>()<br />core/src/Core.php on line 2676</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatchToRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 651</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 662</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRouteWithinStack</strong>()<br />core/vendor/illuminate/routing/Router.php on line 698</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->then</strong>()<br />core/vendor/illuminate/routing/Router.php on line 719</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 103</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 64</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 121</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Middleware\\SubstituteBindings->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/routing/Middleware/SubstituteBindings.php on line 50</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/view/Middleware/ShareErrorsFromSession.php on line 49</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 128</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Route->run</strong>()<br />core/vendor/illuminate/routing/Router.php on line 721</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Route->runCallable</strong>()<br />core/vendor/illuminate/routing/Route.php on line 208</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\RouteFileRegistrar->{closure}</strong>()<br />core/vendor/illuminate/routing/Route.php on line 237</td>\n	</tr>\n</table>\n'),
(12,0,1781104049,3,0,1,'Parser','EvolutionCMS\\Main\\Controllers\\BaseController not exists!'),
(13,0,1781104208,3,0,1,'Parser','EvolutionCMS\\Main\\Controllers\\BaseController not exists!'),
(14,0,1781104410,3,0,1,'Parser','EvolutionCMS\\Main\\Controllers\\BaseController not exists!'),
(15,0,1781104737,3,0,1,'Parser -     $result = (new LeadService())-&gt;han','<h2 style=\"color:red\">&laquo; Evolution CMS Parse Error &raquo;</h2><h3 style=\"color:red\">Class \"EvolutionCMS\\Main\\Services\\LeadService\" not found</h3>\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>File</td>\n		<td>/var/www/kosmos/core/custom/routes.php</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Line</td>\n		<td>9</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Source</td>\n		<td>    $result = (new LeadService())-&gt;handle($request-&gt;all());\n</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>REQUEST_URI</td>\n		<td>http://localhost/api/lead</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Referer</td>\n		<td></td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>User Agent</td>\n		<td>Mozilla/5.0</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>IP</td>\n		<td>127.0.0.1</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Current time</td>\n		<td>2026-06-10 15:18:57</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>MySQL</td>\n		<td>0.0000 s (0 Requests)</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>PHP</td>\n		<td>0.0089 s</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Total</td>\n		<td>0.0089 s</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Memory</td>\n		<td>1.6594009399414 mb</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Core->processRoutes</strong>()<br />index.php on line 137</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatch</strong>()<br />core/src/Core.php on line 2676</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatchToRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 651</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 662</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRouteWithinStack</strong>()<br />core/vendor/illuminate/routing/Router.php on line 698</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->then</strong>()<br />core/vendor/illuminate/routing/Router.php on line 719</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 103</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 64</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 121</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Middleware\\SubstituteBindings->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/routing/Middleware/SubstituteBindings.php on line 50</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/view/Middleware/ShareErrorsFromSession.php on line 49</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 128</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Route->run</strong>()<br />core/vendor/illuminate/routing/Router.php on line 721</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Route->runCallable</strong>()<br />core/vendor/illuminate/routing/Route.php on line 208</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\RouteFileRegistrar->{closure}</strong>()<br />core/vendor/illuminate/routing/Route.php on line 237</td>\n	</tr>\n</table>\n'),
(16,0,1781104737,3,0,1,'Parser -     $result = (new LeadService())-&gt;han','<h2 style=\"color:red\">&laquo; Evolution CMS Parse Error &raquo;</h2><h3 style=\"color:red\">Class \"EvolutionCMS\\Main\\Services\\LeadService\" not found</h3>\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>File</td>\n		<td>/var/www/kosmos/core/custom/routes.php</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Line</td>\n		<td>9</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Source</td>\n		<td>    $result = (new LeadService())-&gt;handle($request-&gt;all());\n</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>REQUEST_URI</td>\n		<td>http://localhost/api/lead</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Referer</td>\n		<td></td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>User Agent</td>\n		<td>Mozilla/5.0</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>IP</td>\n		<td>127.0.0.1</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Current time</td>\n		<td>2026-06-10 15:18:57</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>MySQL</td>\n		<td>0.0000 s (0 Requests)</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>PHP</td>\n		<td>0.0062 s</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Total</td>\n		<td>0.0062 s</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Memory</td>\n		<td>1.6585006713867 mb</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Core->processRoutes</strong>()<br />index.php on line 137</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatch</strong>()<br />core/src/Core.php on line 2676</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatchToRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 651</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 662</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRouteWithinStack</strong>()<br />core/vendor/illuminate/routing/Router.php on line 698</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->then</strong>()<br />core/vendor/illuminate/routing/Router.php on line 719</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 103</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 64</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 121</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Middleware\\SubstituteBindings->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/routing/Middleware/SubstituteBindings.php on line 50</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/view/Middleware/ShareErrorsFromSession.php on line 49</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 128</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Route->run</strong>()<br />core/vendor/illuminate/routing/Router.php on line 721</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Route->runCallable</strong>()<br />core/vendor/illuminate/routing/Route.php on line 208</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\RouteFileRegistrar->{closure}</strong>()<br />core/vendor/illuminate/routing/Route.php on line 237</td>\n	</tr>\n</table>\n'),
(17,0,1781114968,3,0,1,'Parser -                 \'lastmod\'    =&gt; date(\'','<h2 style=\"color:red\">&laquo; Evolution CMS Parse Error &raquo;</h2><h3 style=\"color:red\">date(): Argument #2 ($timestamp) must be of type ?int, Illuminate\\Support\\Carbon given</h3>\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>File</td>\n		<td>/var/www/kosmos/core/custom/packages/main/src/Controllers/SitemapController.php</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Line</td>\n		<td>45</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Source</td>\n		<td>                \'lastmod\'    =&gt; date(\'c\', $doc-&gt;editedon ?: $doc-&gt;createdon ?: time()),\n</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>REQUEST_URI</td>\n		<td>http://78.24.220.193/sitemap.xml</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Resource</td>\n		<td>[8] <a href=\"http://78.24.220.193/sitemap.xml\" target=\"_blank\">Карта сайта XML</a></td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Referer</td>\n		<td></td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>User Agent</td>\n		<td>Go-http-client/1.1</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>IP</td>\n		<td>123.58.215.102</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Current time</td>\n		<td>2026-06-10 18:09:28</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>MySQL</td>\n		<td>0.0000 s (0 Requests)</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>PHP</td>\n		<td>0.0256 s</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Total</td>\n		<td>0.0256 s</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Memory</td>\n		<td>1.6617965698242 mb</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Core->processRoutes</strong>()<br />index.php on line 137</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatch</strong>()<br />core/src/Core.php on line 2676</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatchToRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 651</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 662</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRouteWithinStack</strong>()<br />core/vendor/illuminate/routing/Router.php on line 698</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->then</strong>()<br />core/vendor/illuminate/routing/Router.php on line 719</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 103</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 64</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 121</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Middleware\\SubstituteBindings->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/routing/Middleware/SubstituteBindings.php on line 50</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/view/Middleware/ShareErrorsFromSession.php on line 49</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 128</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Route->run</strong>()<br />core/vendor/illuminate/routing/Router.php on line 721</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Route->runCallable</strong>()<br />core/vendor/illuminate/routing/Route.php on line 208</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Extensions\\Router->EvolutionCMS\\Extensions\\{closure}</strong>()<br />core/vendor/illuminate/routing/Route.php on line 237</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Core->executeParser</strong>()<br />core/src/Extensions/Router.php on line 25</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Core->prepareResponse</strong>()<br />core/src/Core.php on line 2818</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Support\\Facades\\Facade::__callStatic</strong>()<br />core/src/Core.php on line 2905</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\TemplateProcessor->getBladeDocumentContent</strong>()<br />core/vendor/illuminate/support/Facades/Facade.php on line 261</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\Container->call</strong>()<br />core/src/TemplateProcessor.php on line 103</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::call</strong>()<br />core/vendor/illuminate/container/Container.php on line 653</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::callBoundMethod</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 35</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Container\\Util::unwrapIfClosure</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 93</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}</strong>()<br />core/vendor/illuminate/container/Util.php on line 40</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Main\\Controllers\\BaseController->main</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 36</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Main\\Controllers\\SitemapController->setData</strong>()<br />core/custom/packages/main/src/Controllers/BaseController.php on line 15</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>date</strong>()<br />core/custom/packages/main/src/Controllers/SitemapController.php on line 45</td>\n	</tr>\n</table>\n'),
(18,0,1781122012,3,0,1,'Parser -                 \'lastmod\'    =&gt; date(\'','<h2 style=\"color:red\">&laquo; Evolution CMS Parse Error &raquo;</h2><h3 style=\"color:red\">date(): Argument #2 ($timestamp) must be of type ?int, Illuminate\\Support\\Carbon given</h3>\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>File</td>\n		<td>/var/www/kosmos/core/custom/packages/main/src/Controllers/SitemapController.php</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Line</td>\n		<td>45</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Source</td>\n		<td>                \'lastmod\'    =&gt; date(\'c\', $doc-&gt;editedon ?: $doc-&gt;createdon ?: time()),\n</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>REQUEST_URI</td>\n		<td>http://78.24.220.193/sitemap.xml</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Resource</td>\n		<td>[8] <a href=\"http://78.24.220.193/sitemap.xml\" target=\"_blank\">Карта сайта XML</a></td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Referer</td>\n		<td>http://78.24.220.193/manager/?a=27&amp;amp;r=1&amp;amp;id=8</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>User Agent</td>\n		<td>Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>IP</td>\n		<td>95.84.186.169</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Current time</td>\n		<td>2026-06-10 20:06:52</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>MySQL</td>\n		<td>0.0000 s (0 Requests)</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>PHP</td>\n		<td>0.0290 s</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Total</td>\n		<td>0.0290 s</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Memory</td>\n		<td>1.657341003418 mb</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Core->processRoutes</strong>()<br />index.php on line 137</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatch</strong>()<br />core/src/Core.php on line 2676</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatchToRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 651</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 662</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRouteWithinStack</strong>()<br />core/vendor/illuminate/routing/Router.php on line 698</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->then</strong>()<br />core/vendor/illuminate/routing/Router.php on line 719</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 103</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 64</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 121</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Middleware\\SubstituteBindings->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/routing/Middleware/SubstituteBindings.php on line 50</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/view/Middleware/ShareErrorsFromSession.php on line 49</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 128</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Route->run</strong>()<br />core/vendor/illuminate/routing/Router.php on line 721</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Route->runCallable</strong>()<br />core/vendor/illuminate/routing/Route.php on line 208</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Extensions\\Router->EvolutionCMS\\Extensions\\{closure}</strong>()<br />core/vendor/illuminate/routing/Route.php on line 237</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Core->executeParser</strong>()<br />core/src/Extensions/Router.php on line 25</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Core->prepareResponse</strong>()<br />core/src/Core.php on line 2818</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Support\\Facades\\Facade::__callStatic</strong>()<br />core/src/Core.php on line 2905</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\TemplateProcessor->getBladeDocumentContent</strong>()<br />core/vendor/illuminate/support/Facades/Facade.php on line 261</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\Container->call</strong>()<br />core/src/TemplateProcessor.php on line 103</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::call</strong>()<br />core/vendor/illuminate/container/Container.php on line 653</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::callBoundMethod</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 35</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Container\\Util::unwrapIfClosure</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 93</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}</strong>()<br />core/vendor/illuminate/container/Util.php on line 40</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Main\\Controllers\\BaseController->main</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 36</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Main\\Controllers\\SitemapController->setData</strong>()<br />core/custom/packages/main/src/Controllers/BaseController.php on line 15</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>date</strong>()<br />core/custom/packages/main/src/Controllers/SitemapController.php on line 45</td>\n	</tr>\n</table>\n'),
(19,0,1781122175,3,0,1,'Parser -                 \'lastmod\'    =&gt; date(\'','<h2 style=\"color:red\">&laquo; Evolution CMS Parse Error &raquo;</h2><h3 style=\"color:red\">date(): Argument #2 ($timestamp) must be of type ?int, Illuminate\\Support\\Carbon given</h3>\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>File</td>\n		<td>/var/www/kosmos/core/custom/packages/main/src/Controllers/SitemapController.php</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Line</td>\n		<td>45</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Source</td>\n		<td>                \'lastmod\'    =&gt; date(\'c\', $doc-&gt;editedon ?: $doc-&gt;createdon ?: time()),\n</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>REQUEST_URI</td>\n		<td>http://localhost/sitemap.xml</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Resource</td>\n		<td>[8] <a href=\"http://localhost/sitemap.xml\" target=\"_blank\">Карта сайта XML</a></td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Referer</td>\n		<td></td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>User Agent</td>\n		<td>Mozilla/5.0</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>IP</td>\n		<td>127.0.0.1</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Current time</td>\n		<td>2026-06-10 20:09:35</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>MySQL</td>\n		<td>0.0000 s (0 Requests)</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>PHP</td>\n		<td>0.0270 s</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Total</td>\n		<td>0.0270 s</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Memory</td>\n		<td>1.66162109375 mb</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Core->processRoutes</strong>()<br />index.php on line 137</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatch</strong>()<br />core/src/Core.php on line 2676</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatchToRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 651</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 662</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRouteWithinStack</strong>()<br />core/vendor/illuminate/routing/Router.php on line 698</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->then</strong>()<br />core/vendor/illuminate/routing/Router.php on line 719</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 103</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 64</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 121</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Middleware\\SubstituteBindings->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/routing/Middleware/SubstituteBindings.php on line 50</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/view/Middleware/ShareErrorsFromSession.php on line 49</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 128</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Route->run</strong>()<br />core/vendor/illuminate/routing/Router.php on line 721</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Route->runCallable</strong>()<br />core/vendor/illuminate/routing/Route.php on line 208</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Extensions\\Router->EvolutionCMS\\Extensions\\{closure}</strong>()<br />core/vendor/illuminate/routing/Route.php on line 237</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Core->executeParser</strong>()<br />core/src/Extensions/Router.php on line 25</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Core->prepareResponse</strong>()<br />core/src/Core.php on line 2818</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Support\\Facades\\Facade::__callStatic</strong>()<br />core/src/Core.php on line 2905</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\TemplateProcessor->getBladeDocumentContent</strong>()<br />core/vendor/illuminate/support/Facades/Facade.php on line 261</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\Container->call</strong>()<br />core/src/TemplateProcessor.php on line 103</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::call</strong>()<br />core/vendor/illuminate/container/Container.php on line 653</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::callBoundMethod</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 35</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Container\\Util::unwrapIfClosure</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 93</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}</strong>()<br />core/vendor/illuminate/container/Util.php on line 40</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Main\\Controllers\\BaseController->main</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 36</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Main\\Controllers\\SitemapController->setData</strong>()<br />core/custom/packages/main/src/Controllers/BaseController.php on line 15</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>date</strong>()<br />core/custom/packages/main/src/Controllers/SitemapController.php on line 45</td>\n	</tr>\n</table>\n'),
(20,0,1781122175,3,0,1,'Parser -                 \'lastmod\'    =&gt; date(\'','<h2 style=\"color:red\">&laquo; Evolution CMS Parse Error &raquo;</h2><h3 style=\"color:red\">date(): Argument #2 ($timestamp) must be of type ?int, Illuminate\\Support\\Carbon given</h3>\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>File</td>\n		<td>/var/www/kosmos/core/custom/packages/main/src/Controllers/SitemapController.php</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Line</td>\n		<td>45</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Source</td>\n		<td>                \'lastmod\'    =&gt; date(\'c\', $doc-&gt;editedon ?: $doc-&gt;createdon ?: time()),\n</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>REQUEST_URI</td>\n		<td>http://localhost/sitemap.xml</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Resource</td>\n		<td>[8] <a href=\"http://localhost/sitemap.xml\" target=\"_blank\">Карта сайта XML</a></td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Referer</td>\n		<td></td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>User Agent</td>\n		<td>Mozilla/5.0</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>IP</td>\n		<td>127.0.0.1</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Current time</td>\n		<td>2026-06-10 20:09:35</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>MySQL</td>\n		<td>0.0000 s (0 Requests)</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>PHP</td>\n		<td>0.0214 s</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Total</td>\n		<td>0.0214 s</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Memory</td>\n		<td>1.66162109375 mb</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Core->processRoutes</strong>()<br />index.php on line 137</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatch</strong>()<br />core/src/Core.php on line 2676</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatchToRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 651</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 662</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRouteWithinStack</strong>()<br />core/vendor/illuminate/routing/Router.php on line 698</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->then</strong>()<br />core/vendor/illuminate/routing/Router.php on line 719</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 103</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 64</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 121</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Middleware\\SubstituteBindings->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/routing/Middleware/SubstituteBindings.php on line 50</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/view/Middleware/ShareErrorsFromSession.php on line 49</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 128</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Route->run</strong>()<br />core/vendor/illuminate/routing/Router.php on line 721</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Route->runCallable</strong>()<br />core/vendor/illuminate/routing/Route.php on line 208</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Extensions\\Router->EvolutionCMS\\Extensions\\{closure}</strong>()<br />core/vendor/illuminate/routing/Route.php on line 237</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Core->executeParser</strong>()<br />core/src/Extensions/Router.php on line 25</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Core->prepareResponse</strong>()<br />core/src/Core.php on line 2818</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Support\\Facades\\Facade::__callStatic</strong>()<br />core/src/Core.php on line 2905</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\TemplateProcessor->getBladeDocumentContent</strong>()<br />core/vendor/illuminate/support/Facades/Facade.php on line 261</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\Container->call</strong>()<br />core/src/TemplateProcessor.php on line 103</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::call</strong>()<br />core/vendor/illuminate/container/Container.php on line 653</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::callBoundMethod</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 35</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Container\\Util::unwrapIfClosure</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 93</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}</strong>()<br />core/vendor/illuminate/container/Util.php on line 40</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Main\\Controllers\\BaseController->main</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 36</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Main\\Controllers\\SitemapController->setData</strong>()<br />core/custom/packages/main/src/Controllers/BaseController.php on line 15</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>date</strong>()<br />core/custom/packages/main/src/Controllers/SitemapController.php on line 45</td>\n	</tr>\n</table>\n'),
(21,0,1781122337,3,0,1,'Parser -                 \'lastmod\'    =&gt; date(\'','<h2 style=\"color:red\">&laquo; Evolution CMS Parse Error &raquo;</h2><h3 style=\"color:red\">date(): Argument #2 ($timestamp) must be of type ?int, Illuminate\\Support\\Carbon given</h3>\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Error information</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>File</td>\n		<td>/var/www/kosmos/core/custom/packages/main/src/Controllers/SitemapController.php</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Line</td>\n		<td>45</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Source</td>\n		<td>                \'lastmod\'    =&gt; date(\'c\', $doc-&gt;editedon ?: $doc-&gt;createdon ?: time()),\n</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Basic info</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>REQUEST_URI</td>\n		<td>http://localhost/sitemap.xml</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Resource</td>\n		<td>[8] <a href=\"http://localhost/sitemap.xml\" target=\"_blank\">Карта сайта XML</a></td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Referer</td>\n		<td></td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>User Agent</td>\n		<td>curl/8.5.0</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>IP</td>\n		<td>127.0.0.1</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Current time</td>\n		<td>2026-06-10 20:12:17</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th width=\"100px\" >Benchmarks</th>\n		<th></th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td>MySQL</td>\n		<td>0.0000 s (0 Requests)</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>PHP</td>\n		<td>0.0312 s</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td>Total</td>\n		<td>0.0312 s</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td>Memory</td>\n		<td>1.6616821289062 mb</td>\n	</tr>\n</table>\n<br />\n<table class=\"grid\">\n	<thead>\n	<tr class=\"\">\n		<th>Backtrace</th>\n	</tr>\n	</thead>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Core->processRoutes</strong>()<br />index.php on line 137</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatch</strong>()<br />core/src/Core.php on line 2676</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->dispatchToRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 651</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRoute</strong>()<br />core/vendor/illuminate/routing/Router.php on line 662</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->runRouteWithinStack</strong>()<br />core/vendor/illuminate/routing/Router.php on line 698</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->then</strong>()<br />core/vendor/illuminate/routing/Router.php on line 719</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 103</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Session\\Middleware\\StartSession->handleStatefulRequest</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 64</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/session/Middleware/StartSession.php on line 121</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Middleware\\SubstituteBindings->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/routing/Middleware/SubstituteBindings.php on line 50</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 167</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}</strong>()<br />core/vendor/illuminate/view/Middleware/ShareErrorsFromSession.php on line 49</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}</strong>()<br />core/vendor/illuminate/pipeline/Pipeline.php on line 128</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Routing\\Route->run</strong>()<br />core/vendor/illuminate/routing/Router.php on line 721</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Routing\\Route->runCallable</strong>()<br />core/vendor/illuminate/routing/Route.php on line 208</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Extensions\\Router->EvolutionCMS\\Extensions\\{closure}</strong>()<br />core/vendor/illuminate/routing/Route.php on line 237</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Core->executeParser</strong>()<br />core/src/Extensions/Router.php on line 25</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Core->prepareResponse</strong>()<br />core/src/Core.php on line 2818</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Support\\Facades\\Facade::__callStatic</strong>()<br />core/src/Core.php on line 2905</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\TemplateProcessor->getBladeDocumentContent</strong>()<br />core/vendor/illuminate/support/Facades/Facade.php on line 261</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\Container->call</strong>()<br />core/src/TemplateProcessor.php on line 103</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::call</strong>()<br />core/vendor/illuminate/container/Container.php on line 653</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::callBoundMethod</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 35</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>Illuminate\\Container\\Util::unwrapIfClosure</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 93</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}</strong>()<br />core/vendor/illuminate/container/Util.php on line 40</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>EvolutionCMS\\Main\\Controllers\\BaseController->main</strong>()<br />core/vendor/illuminate/container/BoundMethod.php on line 36</td>\n	</tr>\n	<tr class=\"gridItem\">\n		<td><strong>EvolutionCMS\\Main\\Controllers\\SitemapController->setData</strong>()<br />core/custom/packages/main/src/Controllers/BaseController.php on line 15</td>\n	</tr>\n	<tr class=\"gridAltItem\">\n		<td><strong>date</strong>()<br />core/custom/packages/main/src/Controllers/SitemapController.php on line 45</td>\n	</tr>\n</table>\n');
/*!40000 ALTER TABLE `evo_event_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_manager_log`
--

DROP TABLE IF EXISTS `evo_manager_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_manager_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) NOT NULL DEFAULT 0,
  `internalKey` int(11) NOT NULL DEFAULT 0,
  `username` varchar(255) DEFAULT NULL,
  `action` int(11) NOT NULL DEFAULT 0,
  `itemid` varchar(10) DEFAULT '0',
  `itemname` varchar(255) DEFAULT NULL,
  `message` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(45) DEFAULT NULL,
  `useragent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `manager_log_internalkey_index` (`internalKey`),
  KEY `manager_log_action_index` (`action`),
  KEY `manager_log_itemid_index` (`itemid`),
  KEY `manager_log_itemname_index` (`itemname`),
  KEY `manager_log_message_index` (`message`),
  KEY `manager_log_timestamp_index` (`timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_manager_log`
--

LOCK TABLES `evo_manager_log` WRITE;
/*!40000 ALTER TABLE `evo_manager_log` DISABLE KEYS */;
INSERT INTO `evo_manager_log` VALUES
(1,1781104010,1,'admin',58,'-','EVO','Logged in','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(2,1781104010,1,'admin',17,'','-','Editing settings','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(3,1781104023,1,'admin',58,'-','EVO','Logged in','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'),
(4,1781104024,1,'admin',17,'','-','Editing settings','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'),
(5,1781104030,1,'admin',27,'2','Защита кузова','Editing resource','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'),
(6,1781104042,1,'admin',27,'3','Полировка и керамика','Editing resource','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'),
(7,1781121190,1,'admin',58,'-','EVO','Logged in','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(8,1781121191,1,'admin',17,'','-','Editing settings','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(9,1781121249,1,'admin',27,'1','Главная','Editing resource','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(10,1781121544,1,'admin',17,'','-','Editing settings','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(11,1781121551,1,'admin',27,'1','Главная','Editing resource','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(12,1781121696,1,'admin',27,'1','Главная','Editing resource','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(13,1781121704,1,'admin',27,'1','Главная','Editing resource','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(14,1781121707,1,'admin',17,'','-','Editing settings','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(15,1781121709,1,'admin',27,'1','Главная','Editing resource','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(16,1781121716,1,'admin',27,'2','Защита кузова','Editing resource','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(17,1781121721,1,'admin',102,'6','PageBuilder','Edit plugin','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(18,1781121733,1,'admin',103,'6','PageBuilder','Saving plugin','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(19,1781121734,1,'admin',102,'6','PageBuilder','Edit plugin','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(20,1781121736,1,'admin',27,'1','Главная','Editing resource','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(21,1781121764,1,'admin',27,'2','Защита кузова','Editing resource','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(22,1781122009,1,'admin',17,'','-','Editing settings','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(23,1781122011,1,'admin',27,'8','Карта сайта XML','Editing resource','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(24,1781122040,1,'admin',27,'1','Главная','Editing resource','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(25,1781122041,1,'admin',27,'5','Детейлинг салона','Editing resource','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(26,1781135312,1,'admin',27,'2','Защита кузова','Editing resource','95.84.186.169','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36'),
(27,1781187582,1,'admin',58,'-','EVO','Logged in','188.246.181.88','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'),
(28,1781187582,1,'admin',17,'','-','Editing settings','188.246.181.88','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'),
(29,1781187584,1,'admin',27,'2','Защита кузова','Editing resource','188.246.181.88','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'),
(30,1781187589,1,'admin',53,'','-','Viewing system info','188.246.181.88','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36'),
(31,1781187600,1,'admin',27,'1','Главная','Editing resource','188.246.181.88','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36');
/*!40000 ALTER TABLE `evo_manager_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_member_groups`
--

DROP TABLE IF EXISTS `evo_member_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_member_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_group` int(11) NOT NULL DEFAULT 0,
  `member` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_group_member` (`user_group`,`member`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_member_groups`
--

LOCK TABLES `evo_member_groups` WRITE;
/*!40000 ALTER TABLE `evo_member_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `evo_member_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_membergroup_access`
--

DROP TABLE IF EXISTS `evo_membergroup_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_membergroup_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `membergroup` int(11) NOT NULL DEFAULT 0,
  `documentgroup` int(11) NOT NULL DEFAULT 0,
  `context` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_membergroup_access`
--

LOCK TABLES `evo_membergroup_access` WRITE;
/*!40000 ALTER TABLE `evo_membergroup_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `evo_membergroup_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_membergroup_names`
--

DROP TABLE IF EXISTS `evo_membergroup_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_membergroup_names` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(245) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `membergroup_names_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_membergroup_names`
--

LOCK TABLES `evo_membergroup_names` WRITE;
/*!40000 ALTER TABLE `evo_membergroup_names` DISABLE KEYS */;
/*!40000 ALTER TABLE `evo_membergroup_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_migrations`
--

DROP TABLE IF EXISTS `evo_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_migrations`
--

LOCK TABLES `evo_migrations` WRITE;
/*!40000 ALTER TABLE `evo_migrations` DISABLE KEYS */;
INSERT INTO `evo_migrations` VALUES
(1,'2026_06_10_100000_create_pagebuilder_table',1),
(2,'2026_06_10_100010_create_site_leads_table',1),
(3,'2026_06_10_100020_install_pagebuilder_elements',1),
(4,'2026_06_10_100030_install_clientsettings_module',1),
(5,'2026_06_10_100040_create_site_structure',1),
(6,'2026_06_10_100050_seed_pagebuilder_content',1);
/*!40000 ALTER TABLE `evo_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_pagebuilder`
--

DROP TABLE IF EXISTS `evo_pagebuilder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_pagebuilder` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(10) unsigned NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `config` varchar(255) NOT NULL,
  `values` mediumtext NOT NULL,
  `container` varchar(255) DEFAULT NULL,
  `visible` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `index` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `pagebuilder_document_id_container_index` (`document_id`,`container`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_pagebuilder`
--

LOCK TABLES `evo_pagebuilder` WRITE;
/*!40000 ALTER TABLE `evo_pagebuilder` DISABLE KEYS */;
INSERT INTO `evo_pagebuilder` VALUES
(1,2,NULL,'page_hero','{\"image\":\"assets/img/work-049.jpg\",\"eyebrow\":\"PPF · винил · антихром · мото\",\"heading\":\"Защита кузова: плёнка PPF, винил и&nbsp;антихром\",\"lead\":\"Бронируем кузов антигравийным полиуретаном, меняем цвет матовым и глянцевым винилом, затемняем хром. Сохраняем заводское ЛКП и стоимость автомобиля.\",\"btn1_text\":\"Рассчитать стоимость\",\"btn1_link\":\"#zayavka\",\"btn2_text\":\"Задать вопрос\",\"btn2_link\":\"\"}','default',1,0),
(2,2,NULL,'intro_split','{\"tag\":\"Зачем это нужно\",\"heading\":\"Защита, которую видно только в&nbsp;деталях\",\"text\":\"Полиуретановая плёнка PPF принимает на себя сколы от щебня, реагенты и мелкие царапины, а винил позволяет полностью изменить внешний вид без перекраса. Работаем в чистом боксе с лекалами под конкретную модель.\",\"checks\":[{\"text\":\"<b>Антигравийная защита</b> от сколов, песка и реагентов\"},{\"text\":\"<b>Самовосстановление</b> микроцарапин на полиуретане\"},{\"text\":\"<b>Смена цвета</b> винилом без потери гарантии на ЛКП\"},{\"text\":\"<b>Сохранение стоимости</b> авто при продаже\"}],\"image\":\"assets/img/work-037.jpg\",\"image_tag\":\"Защита кузова\"}','default',1,1),
(3,2,NULL,'price_table','{\"eyebrow\":\"Услуги и цены\",\"heading\":\"Оклейка и защита кузова\",\"text\":\"Стоимость зависит от класса, состояния авто и материалов. Точную цену фиксируем в смете после бесплатного осмотра.\",\"rows\":[{\"name\":\"Локальная защита PPF\",\"descr\":\"Капот, фары, пороги, ручки, зоны риска\",\"price\":\"от 22 000 ₽\"},{\"name\":\"Бронирование передней части\",\"descr\":\"Бампер, капот, крылья, зеркала, фары\",\"price\":\"от 180 000 ₽\"},{\"name\":\"Полная оклейка кузова PPF\",\"descr\":\"Максимальная защита всего ЛКП\",\"price\":\"от 200 000 ₽\"},{\"name\":\"Оклейка винилом\",\"descr\":\"Смена цвета: мат, глянец, металлик, сатин\",\"price\":\"от 60 000 ₽\"},{\"name\":\"Антихром\",\"descr\":\"Затемнение хромированных элементов\",\"price\":\"от 8 000 ₽\"},{\"name\":\"Оклейка мотоцикла\",\"descr\":\"Защита и стайлинг мото\",\"price\":\"от 25 000 ₽\"},{\"name\":\"Рекламное брендирование\",\"descr\":\"Коммерческий транспорт, фуры, фургоны\",\"price\":\"по проекту\"}],\"note\":\"* Цены ориентировочные. Итоговая стоимость — в фиксированной смете до начала работ.\"}','default',1,2),
(4,2,NULL,'gallery','{\"anchor\":\"\",\"eyebrow\":\"Наши работы\",\"heading\":\"Примеры по направлению\",\"text\":\"Реальные автомобили из наших боксов. Нажмите для увеличения.\",\"shots\":[{\"image\":\"assets/img/work-049.jpg\",\"thumb\":\"assets/img/thumb/work-049.jpg\",\"tag\":\"Винил\",\"caption\":\"BMW X6 · матовая плёнка\"},{\"image\":\"assets/img/work-058.jpg\",\"thumb\":\"assets/img/thumb/work-058.jpg\",\"tag\":\"Винил\",\"caption\":\"Audi A5 · matte green\"},{\"image\":\"assets/img/work-085.jpg\",\"thumb\":\"assets/img/thumb/work-085.jpg\",\"tag\":\"Винил\",\"caption\":\"SUV · matte grey\"},{\"image\":\"assets/img/work-037.jpg\",\"thumb\":\"assets/img/thumb/work-037.jpg\",\"tag\":\"PPF\",\"caption\":\"Бронирование капота\"},{\"image\":\"assets/img/work-043.jpg\",\"thumb\":\"assets/img/thumb/work-043.jpg\",\"tag\":\"Винил\",\"caption\":\"Audi A6 · процесс оклейки\"},{\"image\":\"assets/img/work-004.jpg\",\"thumb\":\"assets/img/thumb/work-004.jpg\",\"tag\":\"Винил\",\"caption\":\"Audi Q5 · хамелеон\"},{\"image\":\"assets/img/work-099.jpg\",\"thumb\":\"assets/img/thumb/work-099.jpg\",\"tag\":\"Винил\",\"caption\":\"Audi Q5 · детали\"},{\"image\":\"assets/img/work-028.jpg\",\"thumb\":\"assets/img/thumb/work-028.jpg\",\"tag\":\"Коммерция\",\"caption\":\"Оклейка фургона\"},{\"image\":\"assets/img/work-055.jpg\",\"thumb\":\"assets/img/thumb/work-055.jpg\",\"tag\":\"Коммерция\",\"caption\":\"Брендирование тягача\"}],\"more_text\":\"\",\"more_link\":\"\"}','default',1,3),
(5,2,NULL,'features','{\"eyebrow\":\"Почему Космос\",\"heading\":\"Аккуратно, по лекалам, с&nbsp;гарантией\",\"items\":[{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z\\\"/></svg>\",\"title\":\"Плёнки премиум\",\"text\":\"Работаем с проверенными брендами полиуретана и винила\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><circle cx=\\\"12\\\" cy=\\\"12\\\" r=\\\"3\\\"/><path d=\\\"M19 12a7 7 0 00-.1-1l2-1.6-2-3.4-2.4 1a7 7 0 00-1.7-1l-.3-2.5h-4l-.3 2.5a7 7 0 00-1.7 1l-2.4-1-2 3.4 2 1.6a7 7 0 000 2l-2 1.6 2 3.4 2.4-1a7 7 0 001.7 1l.3 2.5h4l.3-2.5a7 7 0 001.7-1l2.4 1 2-3.4-2-1.6a7 7 0 00.1-1z\\\"/></svg>\",\"title\":\"Лекала под модель\",\"text\":\"Точный крой без лишних швов и подрезов на кузове\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M23 7l-7 5 7 5V7z\\\"/><rect x=\\\"1\\\" y=\\\"5\\\" width=\\\"15\\\" height=\\\"14\\\" rx=\\\"2\\\"/></svg>\",\"title\":\"Отчёт по этапам\",\"text\":\"Показываем подготовку и процесс оклейки в мессенджере\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z\\\"/><path d=\\\"M14 2v6h6M9 13h6M9 17h4\\\"/></svg>\",\"title\":\"Гарантия\",\"text\":\"Договор и гарантия на материал и работу\"}]}','default',1,4),
(6,2,NULL,'faq','{\"anchor\":\"\",\"eyebrow\":\"Вопросы и ответы\",\"heading\":\"Частые вопросы\",\"items\":[{\"question\":\"Влияет ли плёнка PPF на радары и датчики?\",\"answer\":\"Нет. Качественный полиуретан прозрачен для штатных радаров, камер и парктроников. Зоны датчиков обрабатываем аккуратно.\"},{\"question\":\"Чем полиуретан отличается от винила?\",\"answer\":\"Полиуретан (PPF) — прозрачная защита от сколов и царапин с эффектом самовосстановления. Винил — это смена цвета и фактуры (мат, глянец, металлик). Часто их комбинируют.\"},{\"question\":\"Сколько служит плёнка?\",\"answer\":\"Качественный полиуретан служит 5–10 лет, винил — 3–7 лет в зависимости от условий эксплуатации и ухода.\"},{\"question\":\"Можно ли мыть авто после оклейки?\",\"answer\":\"Да. Первые дни даём плёнке стабилизироваться, далее — обычный уход. Рекомендуем бесконтактную мойку.\"}]}','default',1,5),
(7,2,NULL,'cta_band','{\"eyebrow\":\"Другие направления\",\"heading\":\"Нужен комплексный уход?\",\"text\":\"Соберём пакет под ваш автомобиль — от защиты кузова до детейлинга салона.\",\"buttons\":[{\"text\":\"Полировка и керамика\",\"link\":\"polirovka-keramika.html\",\"style\":\"ghost\"},{\"text\":\"Записаться\",\"link\":\"kontakty.html\",\"style\":\"primary\"}]}','default',1,6),
(8,2,NULL,'lead_form','{\"eyebrow\":\"Заявка за минуту\",\"heading\":\"Рассчитаем стоимость и&nbsp;запишем на удобное&nbsp;время\",\"lead\":\"Оставьте контакты — перезвоним, бесплатно осмотрим авто и зафиксируем смету. Или сразу напишите нам в мессенджер.\",\"checks\":[{\"text\":\"<b>Бесплатный осмотр</b> и честная смета до работ\"},{\"text\":\"<b>Удобная запись</b> рядом с домом на Васильевском\"},{\"text\":\"<b>Отчёт</b> о каждом этапе в WhatsApp или Telegram\"}],\"chips\":[{\"text\":\"Оклейка / PPF\"},{\"text\":\"Полировка\"},{\"text\":\"Керамика\"},{\"text\":\"Тонировка\"},{\"text\":\"Химчистка\"},{\"text\":\"Предпродажная\"}],\"btn_text\":\"Получить расчёт\",\"show_messengers\":\"1\"}','default',1,7),
(9,3,NULL,'page_hero','{\"image\":\"assets/img/work-093.jpg\",\"eyebrow\":\"Полировка · керамика · защита блеска\",\"heading\":\"Полировка кузова и&nbsp;керамическое покрытие\",\"lead\":\"Убираем голограммы, царапины и затёртости, возвращаем глубину цвета и защищаем результат керамикой. Зеркальный блеск, который держится сезонами.\",\"btn1_text\":\"Рассчитать стоимость\",\"btn1_link\":\"#zayavka\",\"btn2_text\":\"Задать вопрос\",\"btn2_link\":\"\"}','default',1,0),
(10,3,NULL,'intro_split','{\"tag\":\"Глубина и защита\",\"heading\":\"Зеркальный блеск и&nbsp;твёрдая защита ЛКП\",\"text\":\"Восстановительная полировка устраняет дефекты лака, а керамика в несколько слоёв создаёт прочный гидрофобный барьер: грязь меньше липнет, мыть проще, цвет глубже. Подберём состав под бюджет и состояние авто.\",\"checks\":[{\"text\":\"<b>Глубина и зеркальность</b> цвета после полировки\"},{\"text\":\"<b>Защита от царапин</b> и дорожных реагентов\"},{\"text\":\"<b>Гидрофоб</b> — грязь и вода скатываются\"},{\"text\":\"<b>Гарантия на керамику</b> до 12 месяцев\"}],\"image\":\"assets/img/work-097.jpg\",\"image_tag\":\"Полировка и керамика\"}','default',1,1),
(11,3,NULL,'price_table','{\"eyebrow\":\"Услуги и цены\",\"heading\":\"Полировка, керамика и защита\",\"text\":\"Стоимость зависит от класса, состояния авто и материалов. Точную цену фиксируем в смете после бесплатного осмотра.\",\"rows\":[{\"name\":\"Лёгкая защитная полировка\",\"descr\":\"Освежить блеск, убрать лёгкий налёт\",\"price\":\"от 12 000 ₽\"},{\"name\":\"Глубокая восстановительная полировка\",\"descr\":\"Устранение голограмм, царапин, затёртостей\",\"price\":\"от 20 000 ₽\"},{\"name\":\"Жидкое стекло\",\"descr\":\"Бюджетная защита блеска на 3–6 мес.\",\"price\":\"от 8 000 ₽\"},{\"name\":\"Керамика 2 слоя\",\"descr\":\"Прочное гидрофобное покрытие\",\"price\":\"от 18 000 ₽\"},{\"name\":\"Керамика премиум (многослойная)\",\"descr\":\"Максимальная защита и глубина цвета\",\"price\":\"от 30 000 ₽\"},{\"name\":\"Антидождь\",\"descr\":\"Водоотталкивающее покрытие стекла\",\"price\":\"от 1 500 ₽\"},{\"name\":\"Покраска дисков\",\"descr\":\"Комплект, смена цвета дисков\",\"price\":\"от 16 000 ₽\"}],\"note\":\"* Цены ориентировочные. Итоговая стоимость — в фиксированной смете до начала работ.\"}','default',1,2),
(12,3,NULL,'gallery','{\"anchor\":\"\",\"eyebrow\":\"Наши работы\",\"heading\":\"Примеры по направлению\",\"text\":\"Реальные автомобили из наших боксов. Нажмите для увеличения.\",\"shots\":[{\"image\":\"assets/img/work-093.jpg\",\"thumb\":\"assets/img/thumb/work-093.jpg\",\"tag\":\"Керамика\",\"caption\":\"BMW X5 · глубокий блеск\"},{\"image\":\"assets/img/work-097.jpg\",\"thumb\":\"assets/img/thumb/work-097.jpg\",\"tag\":\"Керамика\",\"caption\":\"Чёрный глянец\"},{\"image\":\"assets/img/work-088.jpg\",\"thumb\":\"assets/img/thumb/work-088.jpg\",\"tag\":\"Керамика\",\"caption\":\"BMW X5 · отражения\"},{\"image\":\"assets/img/work-091.jpg\",\"thumb\":\"assets/img/thumb/work-091.jpg\",\"tag\":\"Полировка\",\"caption\":\"SUV · подготовка\"},{\"image\":\"assets/img/work-085.jpg\",\"thumb\":\"assets/img/thumb/work-085.jpg\",\"tag\":\"Защита\",\"caption\":\"SUV · matte\"},{\"image\":\"assets/img/work-058.jpg\",\"thumb\":\"assets/img/thumb/work-058.jpg\",\"tag\":\"Защита\",\"caption\":\"Audi A5\"}],\"more_text\":\"\",\"more_link\":\"\"}','default',1,3),
(13,3,NULL,'features','{\"eyebrow\":\"Почему Космос\",\"heading\":\"Технология, а не&nbsp;«натёрли воском»\",\"items\":[{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18\\\"/></svg>\",\"title\":\"Замер толщины ЛКП\",\"text\":\"Полируем безопасно, контролируя слой лака\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M12 2l2.9 6.3L22 9.3l-5 4.8 1.2 6.9L12 17.8 5.8 21l1.2-6.9-5-4.8 7.1-1z\\\"/></svg>\",\"title\":\"Премиальные составы\",\"text\":\"Профессиональная керамика проверенных брендов\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M23 7l-7 5 7 5V7z\\\"/><rect x=\\\"1\\\" y=\\\"5\\\" width=\\\"15\\\" height=\\\"14\\\" rx=\\\"2\\\"/></svg>\",\"title\":\"Фото до/после\",\"text\":\"Видно реальный результат полировки\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><circle cx=\\\"12\\\" cy=\\\"12\\\" r=\\\"9\\\"/><path d=\\\"M12 7v5l3 2\\\"/></svg>\",\"title\":\"Гарантия и уход\",\"text\":\"Гарантийный талон и рекомендации по мойке\"}]}','default',1,4),
(14,3,NULL,'faq','{\"anchor\":\"\",\"eyebrow\":\"Вопросы и ответы\",\"heading\":\"Частые вопросы\",\"items\":[{\"question\":\"Сколько держится керамика?\",\"answer\":\"Керамика 2 слоя — около 12 месяцев, премиум-многослойная — до 1–3 лет при правильном уходе и бесконтактной мойке.\"},{\"question\":\"Нужна ли полировка перед керамикой?\",\"answer\":\"Да, для лучшего результата. Керамика подчёркивает состояние ЛКП, поэтому сначала убираем дефекты полировкой, затем наносим покрытие.\"},{\"question\":\"Чем керамика лучше жидкого стекла?\",\"answer\":\"Жидкое стекло — базовая защита на 3–6 месяцев. Керамика твёрже, держится дольше и даёт более выраженный гидрофоб и глубину цвета.\"},{\"question\":\"Можно ли мыть авто на обычной мойке?\",\"answer\":\"Можно, но мы рекомендуем бесконтактную мойку без агрессивной химии — так покрытие служит дольше.\"}]}','default',1,5),
(15,3,NULL,'cta_band','{\"eyebrow\":\"Другие направления\",\"heading\":\"Нужен комплексный уход?\",\"text\":\"Соберём пакет под ваш автомобиль — от защиты кузова до детейлинга салона.\",\"buttons\":[{\"text\":\"Защита кузова PPF\",\"link\":\"zashchita-kuzova.html\",\"style\":\"ghost\"},{\"text\":\"Записаться\",\"link\":\"kontakty.html\",\"style\":\"primary\"}]}','default',1,6),
(16,3,NULL,'lead_form','{\"eyebrow\":\"Заявка за минуту\",\"heading\":\"Рассчитаем стоимость и&nbsp;запишем на удобное&nbsp;время\",\"lead\":\"Оставьте контакты — перезвоним, бесплатно осмотрим авто и зафиксируем смету. Или сразу напишите нам в мессенджер.\",\"checks\":[{\"text\":\"<b>Бесплатный осмотр</b> и честная смета до работ\"},{\"text\":\"<b>Удобная запись</b> рядом с домом на Васильевском\"},{\"text\":\"<b>Отчёт</b> о каждом этапе в WhatsApp или Telegram\"}],\"chips\":[{\"text\":\"Оклейка / PPF\"},{\"text\":\"Полировка\"},{\"text\":\"Керамика\"},{\"text\":\"Тонировка\"},{\"text\":\"Химчистка\"},{\"text\":\"Предпродажная\"}],\"btn_text\":\"Получить расчёт\",\"show_messengers\":\"1\"}','default',1,7),
(17,4,NULL,'page_hero','{\"image\":\"assets/img/work-097.jpg\",\"eyebrow\":\"Тонировка · фары · лобовое\",\"heading\":\"Тонировка авто и&nbsp;защита оптики\",\"lead\":\"Тонируем стёкла плёнкой премиум-класса, бронируем и полируем фары, защищаем лобовое от сколов. Комфорт, приватность и аккуратная работа без пузырей.\",\"btn1_text\":\"Рассчитать стоимость\",\"btn1_link\":\"#zayavka\",\"btn2_text\":\"Задать вопрос\",\"btn2_link\":\"\"}','default',1,0),
(18,4,NULL,'intro_split','{\"tag\":\"Комфорт и защита\",\"heading\":\"Меньше солнца, бликов и&nbsp;любопытных глаз\",\"text\":\"Атермальная плёнка снижает нагрев салона и защищает от ультрафиолета, тонировка задней полусферы добавляет приватности, а бронирование фар и лобового спасает оптику и стекло от пескоструя и сколов.\",\"checks\":[{\"text\":\"<b>Приватность</b> и защита салона от выгорания\"},{\"text\":\"<b>Атермалка</b> — меньше жары и нагрева летом\"},{\"text\":\"<b>Защита оптики</b> от камней и пескоструя\"},{\"text\":\"<b>Аккуратный монтаж</b> без пузырей и отслоений\"}],\"image\":\"assets/img/work-025.jpg\",\"image_tag\":\"Тонировка и оптика\"}','default',1,1),
(19,4,NULL,'price_table','{\"eyebrow\":\"Услуги и цены\",\"heading\":\"Тонировка и защита стекла\",\"text\":\"Стоимость зависит от класса, состояния авто и материалов. Точную цену фиксируем в смете после бесплатного осмотра.\",\"rows\":[{\"name\":\"Тонировка задней полусферы\",\"descr\":\"Задние боковые и стекло\",\"price\":\"от 8 000 ₽\"},{\"name\":\"Атермальная тонировка лобового\",\"descr\":\"Защита от жары и UV без затемнения\",\"price\":\"от 6 000 ₽\"},{\"name\":\"Тонировка по ГОСТ (перед)\",\"descr\":\"Допустимая светопропускаемость\",\"price\":\"от 4 000 ₽\"},{\"name\":\"Бронирование фар плёнкой\",\"descr\":\"Защита оптики от сколов\",\"price\":\"от 8 000 ₽\"},{\"name\":\"Защита лобового стекла плёнкой\",\"descr\":\"Антивандальная/антигравийная плёнка\",\"price\":\"от 23 000 ₽\"}],\"note\":\"* Цены ориентировочные. Итоговая стоимость — в фиксированной смете до начала работ.\"}','default',1,2),
(20,4,NULL,'gallery','{\"anchor\":\"\",\"eyebrow\":\"Наши работы\",\"heading\":\"Примеры по направлению\",\"text\":\"Реальные автомобили из наших боксов. Нажмите для увеличения.\",\"shots\":[{\"image\":\"assets/img/work-097.jpg\",\"thumb\":\"assets/img/thumb/work-097.jpg\",\"tag\":\"Оптика\",\"caption\":\"Тёмные стёкла · SUV\"},{\"image\":\"assets/img/work-025.jpg\",\"thumb\":\"assets/img/thumb/work-025.jpg\",\"tag\":\"Салон\",\"caption\":\"Тонировка · комфорт\"},{\"image\":\"assets/img/work-091.jpg\",\"thumb\":\"assets/img/thumb/work-091.jpg\",\"tag\":\"Оптика\",\"caption\":\"SUV · стёкла\"},{\"image\":\"assets/img/work-088.jpg\",\"thumb\":\"assets/img/thumb/work-088.jpg\",\"tag\":\"Оптика\",\"caption\":\"BMW X5\"},{\"image\":\"assets/img/work-085.jpg\",\"thumb\":\"assets/img/thumb/work-085.jpg\",\"tag\":\"Оптика\",\"caption\":\"SUV matte\"}],\"more_text\":\"\",\"more_link\":\"\"}','default',1,3),
(21,4,NULL,'features','{\"eyebrow\":\"Почему Космос\",\"heading\":\"Чисто, ровно и&nbsp;по закону\",\"items\":[{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M12 2l2.9 6.3L22 9.3l-5 4.8 1.2 6.9L12 17.8 5.8 21l1.2-6.9-5-4.8 7.1-1z\\\"/></svg>\",\"title\":\"Плёнки премиум\",\"text\":\"Стабильный цвет, не выгорает и не пузырится\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z\\\"/></svg>\",\"title\":\"По ГОСТ\",\"text\":\"Подскажем допустимую тонировку передних стёкол\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18\\\"/></svg>\",\"title\":\"Атермальные решения\",\"text\":\"Комфорт в салоне летом без сильного затемнения\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z\\\"/><path d=\\\"M14 2v6h6M9 13h6M9 17h4\\\"/></svg>\",\"title\":\"Гарантия\",\"text\":\"Гарантия на плёнку и качество монтажа\"}]}','default',1,4),
(22,4,NULL,'faq','{\"anchor\":\"\",\"eyebrow\":\"Вопросы и ответы\",\"heading\":\"Частые вопросы\",\"items\":[{\"question\":\"Какая тонировка разрешена по ГОСТ?\",\"answer\":\"Лобовое и передние боковые стёкла должны пропускать достаточно света по нормативам. Заднюю полусферу можно тонировать в любой плотности. Подберём допустимый вариант.\"},{\"question\":\"Что даёт атермальная плёнка?\",\"answer\":\"Она снижает нагрев салона и отсекает ультрафиолет, при этом почти не затемняет стекло — комфорт летом и защита приборной панели.\"},{\"question\":\"Надолго ли бронирование фар?\",\"answer\":\"Качественная плёнка служит несколько лет, защищая оптику от сколов и помутнения. При повреждении меняется только плёнка, а не дорогая фара.\"},{\"question\":\"Можно ли вернуть прозрачность старым фарам?\",\"answer\":\"Да, шлифовкой и полировкой убираем желтизну и матовость. Для долговечности результат можно закрепить защитной плёнкой.\"}]}','default',1,5),
(23,4,NULL,'cta_band','{\"eyebrow\":\"Другие направления\",\"heading\":\"Нужен комплексный уход?\",\"text\":\"Соберём пакет под ваш автомобиль — от защиты кузова до детейлинга салона.\",\"buttons\":[{\"text\":\"Детейлинг салона\",\"link\":\"detailing-salona.html\",\"style\":\"ghost\"},{\"text\":\"Записаться\",\"link\":\"kontakty.html\",\"style\":\"primary\"}]}','default',1,6),
(24,4,NULL,'lead_form','{\"eyebrow\":\"Заявка за минуту\",\"heading\":\"Рассчитаем стоимость и&nbsp;запишем на удобное&nbsp;время\",\"lead\":\"Оставьте контакты — перезвоним, бесплатно осмотрим авто и зафиксируем смету. Или сразу напишите нам в мессенджер.\",\"checks\":[{\"text\":\"<b>Бесплатный осмотр</b> и честная смета до работ\"},{\"text\":\"<b>Удобная запись</b> рядом с домом на Васильевском\"},{\"text\":\"<b>Отчёт</b> о каждом этапе в WhatsApp или Telegram\"}],\"chips\":[{\"text\":\"Оклейка / PPF\"},{\"text\":\"Полировка\"},{\"text\":\"Керамика\"},{\"text\":\"Тонировка\"},{\"text\":\"Химчистка\"},{\"text\":\"Предпродажная\"}],\"btn_text\":\"Получить расчёт\",\"show_messengers\":\"1\"}','default',1,7),
(25,5,NULL,'page_hero','{\"image\":\"assets/img/work-025.jpg\",\"eyebrow\":\"Химчистка · кожа · потолок · перетяжка\",\"heading\":\"Детейлинг и&nbsp;химчистка салона\",\"lead\":\"Глубоко чистим салон, убираем запахи озонацией, реставрируем и перетягиваем кожу, перешиваем потолок. Авто выдаём сухим и без запаха — по проверке.\",\"btn1_text\":\"Рассчитать стоимость\",\"btn1_link\":\"#zayavka\",\"btn2_text\":\"Задать вопрос\",\"btn2_link\":\"\"}','default',1,0),
(26,5,NULL,'intro_split','{\"tag\":\"Салон как новый\",\"heading\":\"Чистота, запах нового и&nbsp;уход за&nbsp;кожей\",\"text\":\"Делаем полную химчистку с контролем влажности и принудительной сушкой, восстанавливаем потёртую кожу, перешиваем потолок и элементы интерьера. Используем составы, безопасные для кожи, пластика и текстиля.\",\"checks\":[{\"text\":\"<b>Гарантия сухого салона</b> — выдаём только после проверки\"},{\"text\":\"<b>Безопасная химия</b> для кожи, пластика и ткани\"},{\"text\":\"<b>Озонация</b> — устранение запахов, а не маскировка\"},{\"text\":\"<b>Реставрация кожи</b> и возврат заводского вида\"}],\"image\":\"assets/img/work-097.jpg\",\"image_tag\":\"Детейлинг салона\"}','default',1,1),
(27,5,NULL,'price_table','{\"eyebrow\":\"Услуги и цены\",\"heading\":\"Химчистка, кожа и перетяжка\",\"text\":\"Стоимость зависит от класса, состояния авто и материалов. Точную цену фиксируем в смете после бесплатного осмотра.\",\"rows\":[{\"name\":\"Экспресс-химчистка\",\"descr\":\"Быстрое освежение салона\",\"price\":\"от 4 000 ₽\"},{\"name\":\"Детейлинг-химчистка (полная)\",\"descr\":\"Глубокая чистка всех поверхностей\",\"price\":\"от 12 000 ₽\"},{\"name\":\"Озонация\",\"descr\":\"Устранение запахов и дезинфекция\",\"price\":\"от 2 000 ₽\"},{\"name\":\"Чистка и реставрация кожи\",\"descr\":\"Восстановление потёртостей и цвета\",\"price\":\"от 6 000 ₽\"},{\"name\":\"Перетяжка руля кожей\",\"descr\":\"Натуральная кожа, аккуратный шов\",\"price\":\"от 8 000 ₽\"},{\"name\":\"Перешив потолка\",\"descr\":\"Алькантара или ткань\",\"price\":\"от 18 000 ₽\"},{\"name\":\"Перетяжка салона / элементов\",\"descr\":\"Сиденья, карты дверей, торпедо\",\"price\":\"по проекту\"}],\"note\":\"* Цены ориентировочные. Итоговая стоимость — в фиксированной смете до начала работ.\"}','default',1,2),
(28,5,NULL,'gallery','{\"anchor\":\"\",\"eyebrow\":\"Наши работы\",\"heading\":\"Примеры по направлению\",\"text\":\"Реальные автомобили из наших боксов. Нажмите для увеличения.\",\"shots\":[{\"image\":\"assets/img/work-025.jpg\",\"thumb\":\"assets/img/thumb/work-025.jpg\",\"tag\":\"Салон\",\"caption\":\"Audi A6 · интерьер\"},{\"image\":\"assets/img/work-097.jpg\",\"thumb\":\"assets/img/thumb/work-097.jpg\",\"tag\":\"Премиум\",\"caption\":\"Глянец и салон\"},{\"image\":\"assets/img/work-088.jpg\",\"thumb\":\"assets/img/thumb/work-088.jpg\",\"tag\":\"Премиум\",\"caption\":\"BMW X5\"},{\"image\":\"assets/img/work-091.jpg\",\"thumb\":\"assets/img/thumb/work-091.jpg\",\"tag\":\"Премиум\",\"caption\":\"SUV\"}],\"more_text\":\"\",\"more_link\":\"\"}','default',1,3),
(29,5,NULL,'features','{\"eyebrow\":\"Почему Космос\",\"heading\":\"Чистим технологично, а&nbsp;не «помыли тряпкой»\",\"items\":[{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18\\\"/></svg>\",\"title\":\"Контроль влажности\",\"text\":\"Принудительная сушка — без сырости и плесени\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M12 2l2.9 6.3L22 9.3l-5 4.8 1.2 6.9L12 17.8 5.8 21l1.2-6.9-5-4.8 7.1-1z\\\"/></svg>\",\"title\":\"Уход за кожей\",\"text\":\"Бережные составы и реставрация без блеска\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M23 7l-7 5 7 5V7z\\\"/><rect x=\\\"1\\\" y=\\\"5\\\" width=\\\"15\\\" height=\\\"14\\\" rx=\\\"2\\\"/></svg>\",\"title\":\"Фото-отчёт\",\"text\":\"Показываем проблемные зоны до и после\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z\\\"/><path d=\\\"M14 2v6h6M9 13h6M9 17h4\\\"/></svg>\",\"title\":\"Гарантия результата\",\"text\":\"Сухой салон и устранение запаха\"}]}','default',1,4),
(30,5,NULL,'faq','{\"anchor\":\"\",\"eyebrow\":\"Вопросы и ответы\",\"heading\":\"Частые вопросы\",\"items\":[{\"question\":\"Сколько сохнет салон после химчистки?\",\"answer\":\"Мы сушим салон принудительно и контролируем влажность. Авто выдаём уже сухим, обычно в тот же день — без сырости и запаха.\"},{\"question\":\"Уберёте ли запах животных или табака?\",\"answer\":\"Да. Сочетаем глубокую химчистку с озонацией, которая устраняет источник запаха, а не маскирует его.\"},{\"question\":\"Можно ли восстановить потёртую кожу?\",\"answer\":\"В большинстве случаев да — чистим, реставрируем и тонируем кожу. Сильные повреждения решаем перетяжкой элемента.\"},{\"question\":\"Сколько занимает перетяжка?\",\"answer\":\"Зависит от объёма: руль — от нескольких часов, потолок и сиденья — от 1–2 дней. Сроки называем в смете.\"}]}','default',1,5),
(31,5,NULL,'cta_band','{\"eyebrow\":\"Другие направления\",\"heading\":\"Нужен комплексный уход?\",\"text\":\"Соберём пакет под ваш автомобиль — от защиты кузова до детейлинга салона.\",\"buttons\":[{\"text\":\"Тонировка\",\"link\":\"tonirovka-optika.html\",\"style\":\"ghost\"},{\"text\":\"Записаться\",\"link\":\"kontakty.html\",\"style\":\"primary\"}]}','default',1,6),
(32,5,NULL,'lead_form','{\"eyebrow\":\"Заявка за минуту\",\"heading\":\"Рассчитаем стоимость и&nbsp;запишем на удобное&nbsp;время\",\"lead\":\"Оставьте контакты — перезвоним, бесплатно осмотрим авто и зафиксируем смету. Или сразу напишите нам в мессенджер.\",\"checks\":[{\"text\":\"<b>Бесплатный осмотр</b> и честная смета до работ\"},{\"text\":\"<b>Удобная запись</b> рядом с домом на Васильевском\"},{\"text\":\"<b>Отчёт</b> о каждом этапе в WhatsApp или Telegram\"}],\"chips\":[{\"text\":\"Оклейка / PPF\"},{\"text\":\"Полировка\"},{\"text\":\"Керамика\"},{\"text\":\"Тонировка\"},{\"text\":\"Химчистка\"},{\"text\":\"Предпродажная\"}],\"btn_text\":\"Получить расчёт\",\"show_messengers\":\"1\"}','default',1,7),
(33,6,NULL,'page_hero','{\"image\":\"assets/img/work-085.jpg\",\"eyebrow\":\"Шумка · доводчики · сигнализация · PDR\",\"heading\":\"Комфорт, оборудование и&nbsp;предпродажная подготовка\",\"lead\":\"Делаем салон тише, двери — мягче, авто — безопаснее и аккуратнее. Шумоизоляция, доводчики, сигнализация, выправление вмятин и предпродажный комплекс.\",\"btn1_text\":\"Рассчитать стоимость\",\"btn1_link\":\"#zayavka\",\"btn2_text\":\"Задать вопрос\",\"btn2_link\":\"\"}','default',1,0),
(34,6,NULL,'intro_split','{\"tag\":\"Тишина и комфорт\",\"heading\":\"Премиальные ощущения от&nbsp;каждой поездки\",\"text\":\"Шумоизоляция снижает гул дороги и делает акустику чище, доводчики добавляют плавное закрытие дверей, а сигнализация с автозапуском — комфорт и безопасность. Выправляем вмятины без покраски и готовим авто к продаже.\",\"checks\":[{\"text\":\"<b>Тише в салоне</b> — меньше гул дороги и вибрации\"},{\"text\":\"<b>Мягкое закрытие</b> дверей с доводчиками\"},{\"text\":\"<b>Безопасность</b> — сигнализация и автозапуск\"},{\"text\":\"<b>Товарный вид</b> к продаже без перекраса\"}],\"image\":\"assets/img/work-091.jpg\",\"image_tag\":\"Комфорт и оборудование\"}','default',1,1),
(35,6,NULL,'price_table','{\"eyebrow\":\"Услуги и цены\",\"heading\":\"Оборудование и подготовка\",\"text\":\"Стоимость зависит от класса, состояния авто и материалов. Точную цену фиксируем в смете после бесплатного осмотра.\",\"rows\":[{\"name\":\"Шумоизоляция (зональная)\",\"descr\":\"Арки, двери, пол — по выбранным зонам\",\"price\":\"от 18 000 ₽\"},{\"name\":\"Шумоизоляция (комплексная)\",\"descr\":\"Полный контур, максимальное снижение шума\",\"price\":\"от 85 000 ₽\"},{\"name\":\"Установка доводчиков дверей\",\"descr\":\"Плавное автоматическое закрытие\",\"price\":\"от 25 000 ₽\"},{\"name\":\"Удаление вмятин без покраски (PDR)\",\"descr\":\"Выправление без повреждения ЛКП\",\"price\":\"от 6 000 ₽\"},{\"name\":\"Предпродажная подготовка\",\"descr\":\"Комплекс «товарного вида»\",\"price\":\"от 9 000 ₽\"}],\"note\":\"* Цены ориентировочные. Итоговая стоимость — в фиксированной смете до начала работ.\"}','default',1,2),
(36,6,NULL,'gallery','{\"anchor\":\"\",\"eyebrow\":\"Наши работы\",\"heading\":\"Примеры по направлению\",\"text\":\"Реальные автомобили из наших боксов. Нажмите для увеличения.\",\"shots\":[{\"image\":\"assets/img/work-085.jpg\",\"thumb\":\"assets/img/thumb/work-085.jpg\",\"tag\":\"Комфорт\",\"caption\":\"SUV · подготовка\"},{\"image\":\"assets/img/work-091.jpg\",\"thumb\":\"assets/img/thumb/work-091.jpg\",\"tag\":\"Комфорт\",\"caption\":\"SUV · бокс\"},{\"image\":\"assets/img/work-088.jpg\",\"thumb\":\"assets/img/thumb/work-088.jpg\",\"tag\":\"Подготовка\",\"caption\":\"BMW X5\"},{\"image\":\"assets/img/work-097.jpg\",\"thumb\":\"assets/img/thumb/work-097.jpg\",\"tag\":\"Подготовка\",\"caption\":\"Глянец\"}],\"more_text\":\"\",\"more_link\":\"\"}','default',1,3),
(37,6,NULL,'features','{\"eyebrow\":\"Почему Космос\",\"heading\":\"Делаем как для&nbsp;себя\",\"items\":[{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><circle cx=\\\"12\\\" cy=\\\"12\\\" r=\\\"3\\\"/><path d=\\\"M19 12a7 7 0 00-.1-1l2-1.6-2-3.4-2.4 1a7 7 0 00-1.7-1l-.3-2.5h-4l-.3 2.5a7 7 0 00-1.7 1l-2.4-1-2 3.4 2 1.6a7 7 0 000 2l-2 1.6 2 3.4 2.4-1a7 7 0 001.7 1l.3 2.5h4l.3-2.5a7 7 0 001.7-1l2.4 1 2-3.4-2-1.6a7 7 0 00.1-1z\\\"/></svg>\",\"title\":\"Качественные материалы\",\"text\":\"Шумоизоляция и оборудование проверенных марок\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z\\\"/></svg>\",\"title\":\"Аккуратный монтаж\",\"text\":\"Сборка-разборка без сколов и царапин\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M12 2l2.9 6.3L22 9.3l-5 4.8 1.2 6.9L12 17.8 5.8 21l1.2-6.9-5-4.8 7.1-1z\\\"/></svg>\",\"title\":\"Предпродажный комплекс\",\"text\":\"Полировка, химчистка, оптика — авто как новое\"},{\"icon\":\"<svg viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.5\\\"><path d=\\\"M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z\\\"/><path d=\\\"M14 2v6h6M9 13h6M9 17h4\\\"/></svg>\",\"title\":\"Честная смета\",\"text\":\"Цена и сроки зафиксированы заранее\"}]}','default',1,4),
(38,6,NULL,'faq','{\"anchor\":\"\",\"eyebrow\":\"Вопросы и ответы\",\"heading\":\"Частые вопросы\",\"items\":[{\"question\":\"Стоит ли делать шумоизоляцию?\",\"answer\":\"Если хочется тише и комфортнее — да. Даже частичная шумка по аркам и дверям заметно снижает гул дороги и улучшает звук музыки.\"},{\"question\":\"Доводчики ставятся на любой автомобиль?\",\"answer\":\"Почти на любой современный — подберём комплект под вашу модель. Закрытие дверей становится плавным и бесшумным.\"},{\"question\":\"Реально ли убрать вмятину без покраски?\",\"answer\":\"Да, технологией PDR выправляем вмятины без нарушения заводского ЛКП — при условии, что краска не повреждена.\"},{\"question\":\"Что входит в предпродажную подготовку?\",\"answer\":\"Комплекс зависит от состояния: мойка, полировка, химчистка салона, чернение, подкапотное пространство, оптика. Цель — товарный вид и меньше поводов для торга.\"}]}','default',1,5),
(39,6,NULL,'cta_band','{\"eyebrow\":\"Другие направления\",\"heading\":\"Нужен комплексный уход?\",\"text\":\"Соберём пакет под ваш автомобиль — от защиты кузова до детейлинга салона.\",\"buttons\":[{\"text\":\"Полировка и керамика\",\"link\":\"polirovka-keramika.html\",\"style\":\"ghost\"},{\"text\":\"Записаться\",\"link\":\"kontakty.html\",\"style\":\"primary\"}]}','default',1,6),
(40,6,NULL,'lead_form','{\"eyebrow\":\"Заявка за минуту\",\"heading\":\"Рассчитаем стоимость и&nbsp;запишем на удобное&nbsp;время\",\"lead\":\"Оставьте контакты — перезвоним, бесплатно осмотрим авто и зафиксируем смету. Или сразу напишите нам в мессенджер.\",\"checks\":[{\"text\":\"<b>Бесплатный осмотр</b> и честная смета до работ\"},{\"text\":\"<b>Удобная запись</b> рядом с домом на Васильевском\"},{\"text\":\"<b>Отчёт</b> о каждом этапе в WhatsApp или Telegram\"}],\"chips\":[{\"text\":\"Оклейка / PPF\"},{\"text\":\"Полировка\"},{\"text\":\"Керамика\"},{\"text\":\"Тонировка\"},{\"text\":\"Химчистка\"},{\"text\":\"Предпродажная\"}],\"btn_text\":\"Получить расчёт\",\"show_messengers\":\"1\"}','default',1,7),
(41,1,NULL,'hero_main','{\"image\":\"assets/img/work-004.jpg\",\"image_alt\":\"Автомобиль после детейлинга в студии Космос на Васильевском острове\",\"eyebrow\":\"Санкт-Петербург · Васильевский остров · Кораблестроителей 14\",\"heading\":\"Детейлинг<br>уровня <span class=\\\"shine\\\">орбиты</span>\",\"lead\":\"Технологичный детейлинг на Васильевском острове с <b class=\\\"gold\\\">фиксированной сметой</b>, фото- и видео-контролем работ и гарантией результата. Отдельные чистые боксы — не поток автомойки.\",\"btn1_text\":\"Рассчитать смету\",\"btn1_link\":\"#calculator\",\"btn2_text\":\"Написать в WhatsApp\",\"btn2_link\":\"\",\"counters\":[{\"value\":\"99\",\"suffix\":\"+\",\"label\":\"работ в портфолио\"},{\"value\":\"100\",\"suffix\":\"%\",\"label\":\"работ с фотоотчётом\"},{\"value\":\"6\",\"suffix\":\"\",\"label\":\"изолированных бокса\"},{\"value\":\"10–22\",\"suffix\":\"\",\"label\":\"работаем ежедневно\"}]}','default',1,0),
(42,1,NULL,'trust_strip','{\"items\":[{\"icon\":\"<svg class=\\\"ic\\\" viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.6\\\"><path d=\\\"M9 11l3 3L22 4M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11\\\"/></svg>\",\"title\":\"Фиксированная смета\",\"text\":\"Цену согласуем до начала работ — без скрытых доплат «по факту».\"},{\"icon\":\"<svg class=\\\"ic\\\" viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.6\\\"><path d=\\\"M23 7l-7 5 7 5V7z\\\"/><rect x=\\\"1\\\" y=\\\"5\\\" width=\\\"15\\\" height=\\\"14\\\" rx=\\\"2\\\"/></svg>\",\"title\":\"Фото и видео-отчёт\",\"text\":\"Присылаем этапы работ в ваш мессенджер — вы видите процесс.\"},{\"icon\":\"<svg class=\\\"ic\\\" viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.6\\\"><path d=\\\"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z\\\"/></svg>\",\"title\":\"Договор и гарантия\",\"text\":\"Официальный акт приёмки и гарантия на ключевые услуги.\"},{\"icon\":\"<svg class=\\\"ic\\\" viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" stroke=\\\"currentColor\\\" stroke-width=\\\"1.6\\\"><circle cx=\\\"12\\\" cy=\\\"12\\\" r=\\\"9\\\"/><path d=\\\"M12 7v5l3 2\\\"/></svg>\",\"title\":\"Чёткие сроки\",\"text\":\"Называем срок заранее и выдаём авто вовремя, по проверке.\"}]}','default',1,1),
(43,1,NULL,'compare','{\"eyebrow\":\"Зачем студия, а не мойка\",\"heading\":\"Детейлинг — это не «мойка&nbsp;подороже»\",\"text\":\"Мы работаем в отдельных изолированных боксах с контролируемой чистотой. Премиальный автомобиль не стоит в общем потоке — это разные технологии, материалы и стандарты приёмки.\",\"bad_label\":\"Поточная мойка\",\"bad_title\":\"Конвейер и «по факту»\",\"bad_items\":[{\"text\":\"Цена меняется после приезда\"},{\"text\":\"Общий поток, спешка, риск повредить ЛКП\"},{\"text\":\"Нет отчёта и согласования допработ\"},{\"text\":\"Навязывание услуг на месте\"}],\"good_label\":\"Космос Детейлинг\",\"good_title\":\"Прозрачный премиальный процесс\",\"good_items\":[{\"text\":\"Фиксированная смета до начала работ\"},{\"text\":\"Отдельные чистые боксы и сертифицированные мастера\"},{\"text\":\"Фото/видео каждого этапа в мессенджер\"},{\"text\":\"Договор, гарантия, сухой салон по проверке\"}]}','default',1,2),
(44,1,NULL,'services_grid','{\"eyebrow\":\"Направления студии\",\"heading\":\"Полный уход за&nbsp;автомобилем — от&nbsp;брони до&nbsp;салона\",\"text\":\"Шесть направлений и более 25 услуг. Выберите интересующее — внутри подробности, примеры работ и ориентир по цене.\",\"cards\":[{\"doc_id\":\"2\",\"anchor\":\"\",\"num\":\"01 / Защита\",\"image\":\"assets/img/thumb/work-049.jpg\",\"image_alt\":\"Оклейка авто плёнкой PPF и винил\",\"title\":\"Защита кузова\",\"text\":\"Антигравийный полиуретан PPF, цветной и матовый винил, оклейка передней части, антихром.\",\"tags\":\"PPF, Винил, Антихром, Мото\"},{\"doc_id\":\"3\",\"anchor\":\"\",\"num\":\"02 / Блеск\",\"image\":\"assets/img/thumb/work-093.jpg\",\"image_alt\":\"Полировка кузова и нанесение керамики\",\"title\":\"Полировка и керамика\",\"text\":\"Глубокая восстановительная полировка, керамическое покрытие, жидкое стекло, антидождь, покраска дисков.\",\"tags\":\"Полировка, Керамика, Антидождь\"},{\"doc_id\":\"4\",\"anchor\":\"\",\"num\":\"03 / Оптика\",\"image\":\"assets/img/thumb/work-097.jpg\",\"image_alt\":\"Тонировка стёкол и бронирование фар\",\"title\":\"Тонировка и оптика\",\"text\":\"Тонировка по ГОСТ и атермальная, бронирование и шлифовка фар, защита лобового стекла.\",\"tags\":\"Тонировка, Брони фар, Лобовое\"},{\"doc_id\":\"5\",\"anchor\":\"\",\"num\":\"04 / Салон\",\"image\":\"assets/img/thumb/work-025.jpg\",\"image_alt\":\"Химчистка и детейлинг салона авто\",\"title\":\"Детейлинг салона\",\"text\":\"Глубокая химчистка, реставрация и перетяжка кожи, перешив потолка, озонация, интерьерный детейлинг.\",\"tags\":\"Химчистка, Перетяжка, Кожа, Потолок\"},{\"doc_id\":\"6\",\"anchor\":\"\",\"num\":\"05 / Комфорт\",\"image\":\"assets/img/thumb/work-085.jpg\",\"image_alt\":\"Шумоизоляция, доводчики, сигнализация\",\"title\":\"Комфорт и оборудование\",\"text\":\"Шумоизоляция, доводчики дверей, сигнализация, выпрямление вмятин без покраски, предпродажная подготовка.\",\"tags\":\"Шумка, Доводчики, PDR\"},{\"doc_id\":\"6\",\"anchor\":\"#predprodazhnaya\",\"num\":\"06 / Продажа\",\"image\":\"assets/img/thumb/work-088.jpg\",\"image_alt\":\"Предпродажная подготовка автомобиля\",\"title\":\"Предпродажная подготовка\",\"text\":\"Комплекс «товарного вида»: полировка, химчистка, оптика, подкапотное пространство. Снижает поводы для торга.\",\"tags\":\"Комплекс, Товарный вид\"}]}','default',1,3),
(45,1,NULL,'radar','{\"eyebrow\":\"Интерактивный радар\",\"heading\":\"Карта уязвимостей&nbsp;вашего авто\",\"text\":\"Выберите зону кузова — покажем, что ей угрожает и как мы защищаем. Параметры «до / после» детейлинга.\",\"panel_tag\":\"Cosmos diagnostics · сканирование зон\",\"meta1_value\":\"98.8%\",\"meta1_label\":\"точность защиты\",\"meta2_value\":\"STEK / Krytex\",\"meta2_label\":\"сертиф. материалы\",\"image\":\"assets/img/work-088.jpg\",\"hotspots\":[{\"zone\":\"hood\",\"left\":\"22\",\"top\":\"62\",\"label\":\"Морда · оптика\"},{\"zone\":\"windshield\",\"left\":\"47\",\"top\":\"30\",\"label\":\"Лобовое\"},{\"zone\":\"interior\",\"left\":\"66\",\"top\":\"30\",\"label\":\"Салон\"},{\"zone\":\"sides\",\"left\":\"84\",\"top\":\"52\",\"label\":\"Борта · ЛКП\"},{\"zone\":\"wheels\",\"left\":\"73\",\"top\":\"78\",\"label\":\"Колёса\"}]}','default',1,4),
(46,1,NULL,'calculator','{\"eyebrow\":\"Бортовой калькулятор\",\"heading\":\"Рассчитайте смету&nbsp;за минуту\",\"text\":\"Прозрачный расчёт по классу авто и услугам — или ремонт сколов лобового по формуле ГОСТ. Точную смету фиксируем после осмотра.\",\"mode1_label\":\"Детейлинг и защита\",\"mode2_label\":\"Ремонт сколов · ГОСТ\",\"note\":\"* Ориентировочно. Точная смета — после бесплатного осмотра.\",\"classes\":[{\"id\":\"m\",\"name\":\"Малый / средний класс\",\"multiplier\":\"1\",\"eg\":\"Tesla Model 3, BMW 3, Audi A4, Zeekr X\"},{\"id\":\"p\",\"name\":\"Premium седан / кроссовер\",\"multiplier\":\"1.2\",\"eg\":\"Zeekr 001, BMW 5, Porsche Taycan, Voyah Free\"},{\"id\":\"s\",\"name\":\"Внедорожник / Big SUV\",\"multiplier\":\"1.4\",\"eg\":\"Li L9, BMW X7, Range Rover, Land Cruiser\"},{\"id\":\"c\",\"name\":\"Спорткар / минивэн\",\"multiplier\":\"1.3\",\"eg\":\"Porsche 911, Zeekr 009, Audi R8, Alphard\"}],\"services\":[{\"id\":\"ppf_front\",\"name\":\"Защита «Зоны риска» PPF\",\"sub\":\"Полиуретан на перёд: капот, бампер, фары, зеркала\",\"price\":\"50000\",\"days\":\"2\"},{\"id\":\"ppf_full\",\"name\":\"Полная оклейка кузова PPF\",\"sub\":\"Круговая броня, самовосстановление царапин\",\"price\":\"200000\",\"days\":\"4\"},{\"id\":\"polish_cer\",\"name\":\"Деликатная полировка + керамика 2 слоя\",\"sub\":\"Глубокий блеск и защита на сезон\",\"price\":\"35000\",\"days\":\"2\"},{\"id\":\"polish_corr\",\"name\":\"Восстановительная полировка кузова\",\"sub\":\"Удаление царапин, голограмм, водного камня\",\"price\":\"14000\",\"days\":\"1\"},{\"id\":\"ceramic_pro\",\"name\":\"Керамика премиум (многослойная)\",\"sub\":\"Максимальная защита и глубина цвета\",\"price\":\"30000\",\"days\":\"2\"},{\"id\":\"chem\",\"name\":\"Детейлинг-химчистка салона\",\"sub\":\"Глубокая чистка + озонация, сухой салон\",\"price\":\"12000\",\"days\":\"1\"},{\"id\":\"leather\",\"name\":\"Реставрация и защита кожи\",\"sub\":\"Чистка, восстановление, консервация\",\"price\":\"12000\",\"days\":\"1\"},{\"id\":\"glass\",\"name\":\"Бронирование лобового стекла\",\"sub\":\"Оптическая плёнка от сколов и трещин\",\"price\":\"16000\",\"days\":\"1\"},{\"id\":\"tint\",\"name\":\"Атермальная тонировка по ГОСТ\",\"sub\":\"Меньше жары и UV, по нормативам ДПС\",\"price\":\"9000\",\"days\":\"1\"},{\"id\":\"head\",\"name\":\"Бронирование и полировка фар\",\"sub\":\"Защита и прозрачность оптики\",\"price\":\"6000\",\"days\":\"1\"},{\"id\":\"aqua\",\"name\":\"Антидождь на стёкла\",\"sub\":\"Гидрофоб, рекомендуем в комплексе\",\"price\":\"2000\",\"days\":\"0.5\"}],\"chip_price\":\"1000\",\"ray_price\":\"300\",\"mm_price\":\"150\"}','default',1,5),
(47,1,NULL,'packages','{\"eyebrow\":\"Готовые решения\",\"heading\":\"Пакеты вместо длинного прайса\",\"text\":\"Понятный выбор под задачу: от свежести салона до полной защиты. Точная стоимость фиксируется в смете после осмотра.\",\"items\":[{\"name\":\"Start\",\"price\":\"6 900\",\"featured\":\"\",\"badge\":\"\",\"for\":\"Освежить автомобиль: внешний вид и салон без сложных работ\",\"features\":\"Детейлинг-мойка в 2 фазы\\nЭкспресс-уборка салона\\nЧернение шин, защитный воск\\nОбезжелезивание кузова\",\"btn_text\":\"Выбрать Start\",\"btn_link\":\"#zayavka\"},{\"name\":\"Optimal\",\"price\":\"24 000\",\"featured\":\"1\",\"badge\":\"Хит выбора\",\"for\":\"Глубокий уход и защита блеска на сезон вперёд\",\"features\":\"Всё из пакета Start\\nВосстановительная полировка ЛКП\\nКерамика 2 слоя\\nХимчистка салона + озонация\\nАнтидождь на лобовое\",\"btn_text\":\"Выбрать Optimal\",\"btn_link\":\"#zayavka\"},{\"name\":\"Pro\",\"price\":\"49 000\",\"featured\":\"\",\"badge\":\"\",\"for\":\"Максимальная защита премиального автомобиля\",\"features\":\"Всё из пакета Optimal\\nОклейка зон риска плёнкой PPF\\nМногослойная керамика премиум\\nЗащита кожи и салона\\nГарантийный талон\",\"btn_text\":\"Выбрать Pro\",\"btn_link\":\"#zayavka\"}],\"note\":\"* Цены ориентировочные и зависят от класса и состояния авто. Точная стоимость — в фиксированной смете после бесплатного осмотра.\"}','default',1,6),
(48,1,NULL,'gallery','{\"anchor\":\"raboty\",\"eyebrow\":\"Наши работы\",\"heading\":\"Реальное портфолио&nbsp;— без стоковых картинок\",\"text\":\"Только автомобили, прошедшие через наши боксы. Нажмите на снимок, чтобы рассмотреть детали.\",\"shots\":[{\"image\":\"assets/img/work-005.jpg\",\"thumb\":\"assets/img/thumb/work-005.jpg\",\"tag\":\"Винил\",\"caption\":\"Audi Q5 · матовый хамелеон\"},{\"image\":\"assets/img/work-049.jpg\",\"thumb\":\"assets/img/thumb/work-049.jpg\",\"tag\":\"Винил\",\"caption\":\"BMW X6 · матовая плёнка\"},{\"image\":\"assets/img/work-037.jpg\",\"thumb\":\"assets/img/thumb/work-037.jpg\",\"tag\":\"PPF\",\"caption\":\"Бронирование капота\"},{\"image\":\"assets/img/work-093.jpg\",\"thumb\":\"assets/img/thumb/work-093.jpg\",\"tag\":\"Керамика\",\"caption\":\"BMW X5 · глубокий блеск\"},{\"image\":\"assets/img/work-058.jpg\",\"thumb\":\"assets/img/thumb/work-058.jpg\",\"tag\":\"Винил\",\"caption\":\"Audi A5 · matte green\"},{\"image\":\"assets/img/work-025.jpg\",\"thumb\":\"assets/img/thumb/work-025.jpg\",\"tag\":\"Салон\",\"caption\":\"Audi A6 · интерьер\"},{\"image\":\"assets/img/work-085.jpg\",\"thumb\":\"assets/img/thumb/work-085.jpg\",\"tag\":\"Винил\",\"caption\":\"SUV · matte grey\"},{\"image\":\"assets/img/work-097.jpg\",\"thumb\":\"assets/img/thumb/work-097.jpg\",\"tag\":\"Керамика\",\"caption\":\"Глубокий чёрный глянец\"},{\"image\":\"assets/img/work-008.jpg\",\"thumb\":\"assets/img/thumb/work-008.jpg\",\"tag\":\"Винил\",\"caption\":\"Audi Q5 · детали\"},{\"image\":\"assets/img/work-043.jpg\",\"thumb\":\"assets/img/thumb/work-043.jpg\",\"tag\":\"Винил\",\"caption\":\"Audi A6 · процесс\"},{\"image\":\"assets/img/work-028.jpg\",\"thumb\":\"assets/img/thumb/work-028.jpg\",\"tag\":\"Коммерция\",\"caption\":\"Оклейка фургона\"},{\"image\":\"assets/img/work-055.jpg\",\"thumb\":\"assets/img/thumb/work-055.jpg\",\"tag\":\"Коммерция\",\"caption\":\"Брендирование тягача\"}],\"more_text\":\"Смотреть больше работ и записаться\",\"more_link\":\"kontakty.html\"}','default',1,7),
(49,1,NULL,'process','{\"eyebrow\":\"Как мы работаем\",\"heading\":\"Прозрачный путь автомобиля\",\"steps\":[{\"title\":\"Осмотр и смета\",\"text\":\"Бесплатно оцениваем состояние, фиксируем смету и сроки. Без доплат «по факту».\"},{\"title\":\"Приёмка по акту\",\"text\":\"Фотофиксация всех зон и спорных мест. Согласуем объём работ письменно.\"},{\"title\":\"Работа с отчётом\",\"text\":\"Делаем в чистом боксе и присылаем этапы в мессенджер в реальном времени.\"},{\"title\":\"Выдача и гарантия\",\"text\":\"Проверяем результат вместе с вами, выдаём гарантию и рекомендации по уходу.\"}]}','default',1,8),
(50,1,NULL,'stats','{\"items\":[{\"value\":\"99\",\"suffix\":\"+\",\"label\":\"работ в портфолио\"},{\"value\":\"25\",\"suffix\":\"+\",\"label\":\"услуг детейлинга\"},{\"value\":\"100\",\"suffix\":\"%\",\"label\":\"работ с фотоотчётом\"},{\"value\":\"12\",\"suffix\":\" мес\",\"label\":\"гарантия на керамику\"}]}','default',1,9),
(51,1,NULL,'china_split','{\"eyebrow\":\"Новые премиум-бренды\",\"heading\":\"Знаем специфику китайских&nbsp;премиум-авто\",\"lead\":\"Zeekr, Li, Voyah, Tank и другие активно растут в премиальном сегменте. У них особая сборка и мягкое ЛКП — мы подбираем плёнку, полироль и керамику под конкретную модель.\",\"brands\":[{\"name\":\"Zeekr\"},{\"name\":\"Li (Lixiang)\"},{\"name\":\"Voyah\"},{\"name\":\"Tank\"},{\"name\":\"Avatr\"},{\"name\":\"Exeed\"},{\"name\":\"Hongqi\"}],\"btn_text\":\"Подобрать уход для авто\",\"btn_link\":\"#zayavka\",\"image\":\"assets/img/work-091.jpg\",\"image_alt\":\"Уход за современным премиальным внедорожником\",\"image_tag\":\"Премиум-сегмент\"}','default',1,10),
(52,1,NULL,'reviews','{\"eyebrow\":\"Отзывы клиентов\",\"heading\":\"Нам доверяют дорогие автомобили\",\"text\":\"Реальные отзывы подключаются из карточек Яндекс&nbsp;Карт и 2ГИС. Ниже — примеры.\",\"items\":[{\"stars\":\"5\",\"name\":\"Дмитрий К.\",\"car\":\"Audi Q5 · керамика\",\"text\":\"Делал керамику на Q5 — прислали фото каждого этапа прямо в Telegram. Смету назвали сразу и не изменили. Блеск держится отлично.\"},{\"stars\":\"5\",\"name\":\"Марина С.\",\"car\":\"BMW X6 · PPF + тонировка\",\"text\":\"Оклеили перед в полиуретан и затонировали. Аккуратно, в срок, бокс чистый — видно, что это студия, а не мойка при заправке. Рекомендую.\"},{\"stars\":\"5\",\"name\":\"Алексей В.\",\"car\":\"Mercedes · предпродажная\",\"text\":\"Брал предпродажную подготовку. Машину было не узнать — продал быстро и без торга по мелочам. Спасибо за честный подход и отчёт.\"}]}','default',1,11),
(53,1,NULL,'faq','{\"anchor\":\"faq\",\"eyebrow\":\"Вопросы и мифы\",\"heading\":\"Коротко о&nbsp;главном\",\"items\":[{\"question\":\"Влияет ли плёнка PPF на радары и датчики парковки?\",\"answer\":\"Нет. Качественный полиуретан прозрачен для штатных радаров, камер и парктроников. Мы используем плёнки проверенных брендов и аккуратно обрабатываем зоны датчиков.\"},{\"question\":\"Чем керамика отличается от жидкого стекла?\",\"answer\":\"Жидкое стекло — это базовая защита на 3–6 месяцев. Профессиональная керамика в несколько слоёв даёт более твёрдое покрытие, глубину цвета и держится до 1–3 лет. Подберём вариант под бюджет и задачи.\"},{\"question\":\"Сколько сохнет салон после химчистки?\",\"answer\":\"Мы сушим салон принудительно и контролируем влажность. Авто выдаём только после проверки — без сырости и запаха. Гарантируем сухой салон.\"},{\"question\":\"Можно ли узнать цену заранее?\",\"answer\":\"Да. После осмотра мы фиксируем смету до начала работ. Любые дополнительные работы согласуем отдельно по фото — без неожиданных доплат.\"},{\"question\":\"Где вы находитесь и как заехать?\",\"answer\":\"Санкт-Петербург, Васильевский остров, ул. Кораблестроителей, 14 — рядом с гостиницей Cosmos, удобный съезд с ЗСД. Подробности и карта на странице «Контакты».\"}]}','default',1,12),
(54,1,NULL,'booking','{\"eyebrow\":\"Онлайн-запись\",\"heading\":\"Запишитесь на&nbsp;удобное окошко\",\"text\":\"Выберите услугу, день и свободное время — мы подтвердим запись и заранее подготовим бокс.\",\"btn_text\":\"Записаться\"}','default',1,13),
(55,1,NULL,'lead_form','{\"eyebrow\":\"Заявка за минуту\",\"heading\":\"Рассчитаем стоимость и&nbsp;запишем на удобное&nbsp;время\",\"lead\":\"Оставьте контакты — перезвоним, бесплатно осмотрим авто и зафиксируем смету. Или сразу напишите нам в мессенджер.\",\"checks\":[{\"text\":\"<b>Бесплатный осмотр</b> и честная смета до работ\"},{\"text\":\"<b>Удобная запись</b> рядом с домом на Васильевском\"},{\"text\":\"<b>Отчёт</b> о каждом этапе в WhatsApp или Telegram\"}],\"chips\":[{\"text\":\"Оклейка / PPF\"},{\"text\":\"Полировка\"},{\"text\":\"Керамика\"},{\"text\":\"Тонировка\"},{\"text\":\"Химчистка\"},{\"text\":\"Предпродажная\"}],\"btn_text\":\"Получить расчёт\",\"show_messengers\":\"1\"}','default',1,14),
(56,7,NULL,'page_hero','{\"image\":\"assets/img/work-005.jpg\",\"eyebrow\":\"Васильевский остров · Намыв\",\"heading\":\"Контакты и&nbsp;как нас найти\",\"lead\":\"Мы на Васильевском острове — рядом с гостиницей Cosmos, удобный съезд с ЗСД. Запишитесь по телефону, в мессенджере или через форму ниже.\",\"btn1_text\":\"\",\"btn1_link\":\"\",\"btn2_text\":\"\",\"btn2_link\":\"\"}','default',1,0),
(57,7,NULL,'contacts_info','{\"checks\":[{\"text\":\"<b>На автомобиле:</b> удобный съезд с ЗСД, парковка у студии\"},{\"text\":\"<b>Ориентир:</b> рядом гостиница Cosmos / Прибалтийская\"},{\"text\":\"<b>Рядом метро</b> Приморская, районы Намыв и В.О.\"}],\"map_embed\":\"\"}','default',1,1),
(58,7,NULL,'lead_form','{\"eyebrow\":\"Заявка за минуту\",\"heading\":\"Запишитесь на&nbsp;осмотр и&nbsp;расчёт\",\"lead\":\"Оставьте контакты — перезвоним, бесплатно осмотрим авто и зафиксируем смету. Работаем по записи, чтобы вам не ждать в очереди.\",\"checks\":[{\"text\":\"<b>Бесплатный осмотр</b> и честная смета до работ\"},{\"text\":\"<b>Фото/видео-отчёт</b> о каждом этапе\"},{\"text\":\"<b>Гарантия</b> на ключевые услуги\"}],\"chips\":[{\"text\":\"Оклейка / PPF\"},{\"text\":\"Полировка\"},{\"text\":\"Керамика\"},{\"text\":\"Тонировка\"},{\"text\":\"Химчистка\"},{\"text\":\"Предпродажная\"}],\"btn_text\":\"Получить расчёт\",\"show_messengers\":\"1\"}','default',1,2),
(59,9,NULL,'page_hero','{\"image\":\"assets/img/work-091.jpg\",\"eyebrow\":\"Ошибка 404\",\"heading\":\"Страница не&nbsp;найдена\",\"lead\":\"Такой страницы нет или она переехала. Вернитесь на главную или выберите направление в меню.\",\"btn1_text\":\"На главную\",\"btn1_link\":\"index.html\",\"btn2_text\":\"Контакты\",\"btn2_link\":\"kontakty.html\"}','default',1,0);
/*!40000 ALTER TABLE `evo_pagebuilder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_permissions`
--

DROP TABLE IF EXISTS `evo_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `lang_key` varchar(255) NOT NULL DEFAULT '',
  `group_id` int(11) DEFAULT NULL,
  `disabled` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_permissions`
--

LOCK TABLES `evo_permissions` WRITE;
/*!40000 ALTER TABLE `evo_permissions` DISABLE KEYS */;
INSERT INTO `evo_permissions` VALUES
(1,'Request manager frames','frames','role_frames',1,1,NULL,NULL),
(2,'Request manager intro page','home','role_home',1,1,NULL,NULL),
(3,'Log out of the manager','logout','role_logout',1,1,NULL,NULL),
(4,'View help pages','help','role_help',1,0,NULL,NULL),
(5,'View action completed screen','action_ok','role_actionok',1,1,NULL,NULL),
(6,'View error dialog','error_dialog','role_errors',1,1,NULL,NULL),
(7,'View the about page','about','role_about',1,1,NULL,NULL),
(8,'View credits','credits','role_credits',1,1,NULL,NULL),
(9,'Change password','change_password','role_change_password',1,0,NULL,NULL),
(10,'Save password','save_password','role_save_password',1,0,NULL,NULL),
(11,'View a Resource\'s data','view_document','role_view_docdata',2,1,NULL,NULL),
(12,'Create new Resources','new_document','role_create_doc',2,0,NULL,NULL),
(13,'Edit a Resource','edit_document','role_edit_doc',2,0,NULL,NULL),
(14,'Change Resource-Type','change_resourcetype','role_change_resourcetype',2,0,NULL,NULL),
(15,'Save Resources','save_document','role_save_doc',2,0,NULL,NULL),
(16,'Publish Resources','publish_document','role_publish_doc',2,0,NULL,NULL),
(17,'Delete Resources','delete_document','role_delete_doc',2,0,NULL,NULL),
(18,'Permanently purge deleted Resources','empty_trash','role_empty_trash',2,0,NULL,NULL),
(19,'Empty the site\'s cache','empty_cache','role_cache_refresh',2,0,NULL,NULL),
(20,'View Unpublished Resources','view_unpublished','role_view_unpublished',2,0,NULL,NULL),
(21,'Use the file manager (full root access)','file_manager','role_file_manager',3,0,NULL,NULL),
(22,'Manage assets/files','assets_files','role_assets_files',3,0,NULL,NULL),
(23,'Manage assets/images','assets_images','role_assets_images',3,0,NULL,NULL),
(24,'Use the Category Manager','category_manager','role_category_manager',4,0,NULL,NULL),
(25,'Create new Module','new_module','role_new_module',5,0,NULL,NULL),
(26,'Edit Module','edit_module','role_edit_module',5,0,NULL,NULL),
(27,'Save Module','save_module','role_save_module',5,0,NULL,NULL),
(28,'Delete Module','delete_module','role_delete_module',5,0,NULL,NULL),
(29,'Run Module','exec_module','role_run_module',5,0,NULL,NULL),
(30,'List Module','list_module','role_list_module',5,0,NULL,NULL),
(31,'Create new site Templates','new_template','role_create_template',6,0,NULL,NULL),
(32,'Edit site Templates','edit_template','role_edit_template',6,0,NULL,NULL),
(33,'Save Templates','save_template','role_save_template',6,0,NULL,NULL),
(34,'Delete Templates','delete_template','role_delete_template',6,0,NULL,NULL),
(35,'Create new Snippets','new_snippet','role_create_snippet',7,0,NULL,NULL),
(36,'Edit Snippets','edit_snippet','role_edit_snippet',7,0,NULL,NULL),
(37,'Save Snippets','save_snippet','role_save_snippet',7,0,NULL,NULL),
(38,'Delete Snippets','delete_snippet','role_delete_snippet',7,0,NULL,NULL),
(39,'Create new Chunks','new_chunk','role_create_chunk',8,0,NULL,NULL),
(40,'Edit Chunks','edit_chunk','role_edit_chunk',8,0,NULL,NULL),
(41,'Save Chunks','save_chunk','role_save_chunk',8,0,NULL,NULL),
(42,'Delete Chunks','delete_chunk','role_delete_chunk',8,0,NULL,NULL),
(43,'Create new Plugins','new_plugin','role_create_plugin',9,0,NULL,NULL),
(44,'Edit Plugins','edit_plugin','role_edit_plugin',9,0,NULL,NULL),
(45,'Save Plugins','save_plugin','role_save_plugin',9,0,NULL,NULL),
(46,'Delete Plugins','delete_plugin','role_delete_plugin',9,0,NULL,NULL),
(47,'Create new users','new_user','role_new_user',10,0,NULL,NULL),
(48,'Edit users','edit_user','role_edit_user',10,0,NULL,NULL),
(49,'Save users','save_user','role_save_user',10,0,NULL,NULL),
(50,'Delete users','delete_user','role_delete_user',10,0,NULL,NULL),
(51,'Manager access permissions','access_permissions','manager_access_permissions',11,0,NULL,NULL),
(52,'Manage document and user groups','manage_groups','manage_groups',11,0,NULL,NULL),
(53,'Manage document permissions','manage_document_permissions','manage_document_permissions',11,0,NULL,NULL),
(54,'Manage module permissions','manage_module_permissions','manage_module_permissions',11,0,NULL,NULL),
(55,'Manage TV permissions','manage_tv_permissions','manage_tv_permissions',11,0,NULL,NULL),
(56,'Create new roles','new_role','role_new_role',12,0,NULL,NULL),
(57,'Edit roles','edit_role','role_edit_role',12,0,NULL,NULL),
(58,'Save roles','save_role','role_save_role',12,0,NULL,NULL),
(59,'Delete roles','delete_role','role_delete_role',12,0,NULL,NULL),
(60,'View event log','view_eventlog','role_view_eventlog',13,0,NULL,NULL),
(61,'Delete event log','delete_eventlog','role_delete_eventlog',13,0,NULL,NULL),
(62,'View system logs','logs','role_view_logs',14,0,NULL,NULL),
(63,'Change site settings','settings','role_edit_settings',14,0,NULL,NULL),
(64,'Use the Backup Manager','bk_manager','role_bk_manager',14,0,NULL,NULL),
(65,'Remove Locks','remove_locks','role_remove_locks',14,0,NULL,NULL),
(66,'Display Locks','display_locks','role_display_locks',14,0,NULL,NULL);
/*!40000 ALTER TABLE `evo_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_permissions_groups`
--

DROP TABLE IF EXISTS `evo_permissions_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_permissions_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `lang_key` varchar(255) NOT NULL DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_permissions_groups`
--

LOCK TABLES `evo_permissions_groups` WRITE;
/*!40000 ALTER TABLE `evo_permissions_groups` DISABLE KEYS */;
INSERT INTO `evo_permissions_groups` VALUES
(1,'General','page_data_general',NULL,NULL),
(2,'Content Management','role_content_management',NULL,NULL),
(3,'File Management','role_file_management',NULL,NULL),
(4,'Category Management','category_management',NULL,NULL),
(5,'Module Management','role_module_management',NULL,NULL),
(6,'Template Management','role_template_management',NULL,NULL),
(7,'Snippet Management','role_snippet_management',NULL,NULL),
(8,'Chunk Management','role_chunk_management',NULL,NULL),
(9,'Plugin Management','role_plugin_management',NULL,NULL),
(10,'User Management','role_user_management',NULL,NULL),
(11,'Permissions','role_udperms',NULL,NULL),
(12,'Role Management','role_role_management',NULL,NULL),
(13,'Events Log Management','role_eventlog_management',NULL,NULL),
(14,'Config Management','role_config_management',NULL,NULL);
/*!40000 ALTER TABLE `evo_permissions_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_role_permissions`
--

DROP TABLE IF EXISTS `evo_role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_role_permissions`
--

LOCK TABLES `evo_role_permissions` WRITE;
/*!40000 ALTER TABLE `evo_role_permissions` DISABLE KEYS */;
INSERT INTO `evo_role_permissions` VALUES
(1,'frames',1,NULL,NULL),
(2,'home',1,NULL,NULL),
(3,'logout',1,NULL,NULL),
(4,'help',1,NULL,NULL),
(5,'role_actionok',1,NULL,NULL),
(6,'error_dialog',1,NULL,NULL),
(7,'about',1,NULL,NULL),
(8,'credits',1,NULL,NULL),
(9,'change_password',1,NULL,NULL),
(10,'save_password',1,NULL,NULL),
(11,'view_document',1,NULL,NULL),
(12,'new_document',1,NULL,NULL),
(13,'edit_document',1,NULL,NULL),
(14,'change_resourcetype',1,NULL,NULL),
(15,'save_document',1,NULL,NULL),
(16,'publish_document',1,NULL,NULL),
(17,'delete_document',1,NULL,NULL),
(18,'empty_trash',1,NULL,NULL),
(19,'empty_cache',1,NULL,NULL),
(20,'view_unpublished',1,NULL,NULL),
(21,'file_manager',1,NULL,NULL),
(22,'assets_files',1,NULL,NULL),
(23,'assets_images',1,NULL,NULL),
(24,'category_manager',1,NULL,NULL),
(25,'new_module',1,NULL,NULL),
(26,'edit_module',1,NULL,NULL),
(27,'save_module',1,NULL,NULL),
(28,'delete_module',1,NULL,NULL),
(29,'exec_module',1,NULL,NULL),
(30,'list_module',1,NULL,NULL),
(31,'new_template',1,NULL,NULL),
(32,'edit_template',1,NULL,NULL),
(33,'save_template',1,NULL,NULL),
(34,'delete_template',1,NULL,NULL),
(35,'new_snippet',1,NULL,NULL),
(36,'edit_snippet',1,NULL,NULL),
(37,'save_snippet',1,NULL,NULL),
(38,'delete_snippet',1,NULL,NULL),
(39,'new_chunk',1,NULL,NULL),
(40,'edit_chunk',1,NULL,NULL),
(41,'save_chunk',1,NULL,NULL),
(42,'delete_chunk',1,NULL,NULL),
(43,'new_plugin',1,NULL,NULL),
(44,'edit_plugin',1,NULL,NULL),
(45,'save_plugin',1,NULL,NULL),
(46,'delete_plugin',1,NULL,NULL),
(47,'new_user',1,NULL,NULL),
(48,'edit_user',1,NULL,NULL),
(49,'save_user',1,NULL,NULL),
(50,'delete_user',1,NULL,NULL),
(51,'access_permissions',1,NULL,NULL),
(52,'manage_groups',1,NULL,NULL),
(53,'manage_document_permissions',1,NULL,NULL),
(54,'manage_module_permissions',1,NULL,NULL),
(55,'manage_tv_permissions',1,NULL,NULL),
(56,'new_role',1,NULL,NULL),
(57,'edit_role',1,NULL,NULL),
(58,'save_role',1,NULL,NULL),
(59,'delete_role',1,NULL,NULL),
(60,'view_eventlog',1,NULL,NULL),
(61,'delete_eventlog',1,NULL,NULL),
(62,'logs',1,NULL,NULL),
(63,'settings',1,NULL,NULL),
(64,'bk_manager',1,NULL,NULL),
(65,'remove_locks',1,NULL,NULL),
(66,'display_locks',1,NULL,NULL),
(67,'frames',2,NULL,NULL),
(68,'home',2,NULL,NULL),
(69,'logout',2,NULL,NULL),
(70,'help',2,NULL,NULL),
(71,'role_actionok',2,NULL,NULL),
(72,'error_dialog',2,NULL,NULL),
(73,'about',2,NULL,NULL),
(74,'credits',2,NULL,NULL),
(75,'change_password',2,NULL,NULL),
(76,'save_password',2,NULL,NULL),
(77,'view_document',2,NULL,NULL),
(78,'new_document',2,NULL,NULL),
(79,'edit_document',2,NULL,NULL),
(80,'change_resourcetype',2,NULL,NULL),
(81,'save_document',2,NULL,NULL),
(82,'publish_document',2,NULL,NULL),
(83,'delete_document',2,NULL,NULL),
(84,'empty_cache',2,NULL,NULL),
(85,'view_unpublished',2,NULL,NULL),
(86,'file_manager',2,NULL,NULL),
(87,'assets_files',2,NULL,NULL),
(88,'assets_images',2,NULL,NULL),
(89,'exec_module',2,NULL,NULL),
(90,'list_module',2,NULL,NULL),
(91,'edit_chunk',2,NULL,NULL),
(92,'save_chunk',2,NULL,NULL),
(93,'remove_locks',2,NULL,NULL),
(94,'display_locks',2,NULL,NULL),
(95,'access_permissions',2,NULL,NULL),
(96,'manage_document_permissions',2,NULL,NULL),
(97,'frames',3,NULL,NULL),
(98,'home',3,NULL,NULL),
(99,'logout',3,NULL,NULL),
(100,'help',3,NULL,NULL),
(101,'role_actionok',3,NULL,NULL),
(102,'error_dialog',3,NULL,NULL),
(103,'about',3,NULL,NULL),
(104,'credits',3,NULL,NULL),
(105,'change_password',3,NULL,NULL),
(106,'save_password',3,NULL,NULL),
(107,'view_document',3,NULL,NULL),
(108,'new_document',3,NULL,NULL),
(109,'edit_document',3,NULL,NULL),
(110,'change_resourcetype',3,NULL,NULL),
(111,'save_document',3,NULL,NULL),
(112,'publish_document',3,NULL,NULL),
(113,'delete_document',3,NULL,NULL),
(114,'empty_trash',3,NULL,NULL),
(115,'empty_cache',3,NULL,NULL),
(116,'view_unpublished',3,NULL,NULL),
(117,'file_manager',3,NULL,NULL),
(118,'assets_files',3,NULL,NULL),
(119,'assets_images',3,NULL,NULL),
(120,'exec_module',3,NULL,NULL),
(121,'list_module',3,NULL,NULL),
(122,'new_template',3,NULL,NULL),
(123,'edit_template',3,NULL,NULL),
(124,'save_template',3,NULL,NULL),
(125,'delete_template',3,NULL,NULL),
(126,'new_chunk',3,NULL,NULL),
(127,'edit_chunk',3,NULL,NULL),
(128,'save_chunk',3,NULL,NULL),
(129,'delete_chunk',3,NULL,NULL),
(130,'new_user',3,NULL,NULL),
(131,'edit_user',3,NULL,NULL),
(132,'save_user',3,NULL,NULL),
(133,'delete_user',3,NULL,NULL),
(134,'logs',3,NULL,NULL),
(135,'settings',3,NULL,NULL),
(136,'bk_manager',3,NULL,NULL),
(137,'remove_locks',3,NULL,NULL),
(138,'display_locks',3,NULL,NULL),
(139,'access_permissions',3,NULL,NULL),
(140,'manage_document_permissions',3,NULL,NULL);
/*!40000 ALTER TABLE `evo_role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_content`
--

DROP TABLE IF EXISTS `evo_site_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL DEFAULT 'document',
  `contentType` varchar(50) NOT NULL DEFAULT 'text/html',
  `pagetitle` varchar(255) NOT NULL DEFAULT '',
  `longtitle` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(245) DEFAULT '',
  `link_attributes` varchar(255) NOT NULL DEFAULT '' COMMENT 'Link attriubtes',
  `published` int(11) NOT NULL DEFAULT 0,
  `pub_date` int(11) NOT NULL DEFAULT 0,
  `unpub_date` int(11) NOT NULL DEFAULT 0,
  `parent` int(11) NOT NULL DEFAULT 0,
  `isfolder` int(11) NOT NULL DEFAULT 0,
  `introtext` text DEFAULT NULL COMMENT 'Used to provide quick summary of the document',
  `content` longtext DEFAULT NULL,
  `richtext` tinyint(1) NOT NULL DEFAULT 1,
  `template` int(11) NOT NULL DEFAULT 0,
  `menuindex` int(11) NOT NULL DEFAULT 0,
  `searchable` int(11) NOT NULL DEFAULT 1,
  `cacheable` int(11) NOT NULL DEFAULT 1,
  `createdby` int(11) NOT NULL DEFAULT 0,
  `createdon` int(11) NOT NULL DEFAULT 0,
  `editedby` int(11) NOT NULL DEFAULT 0,
  `editedon` int(11) NOT NULL DEFAULT 0,
  `deleted` int(11) NOT NULL DEFAULT 0,
  `deletedon` int(11) NOT NULL DEFAULT 0,
  `deletedby` int(11) NOT NULL DEFAULT 0,
  `publishedon` int(11) NOT NULL DEFAULT 0 COMMENT 'Date the document was published',
  `publishedby` int(11) NOT NULL DEFAULT 0 COMMENT 'ID of user who published the document',
  `menutitle` varchar(255) NOT NULL DEFAULT '' COMMENT 'Menu title',
  `hide_from_tree` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Disable page hit count',
  `privateweb` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Private web document',
  `privatemgr` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Private manager document',
  `content_dispo` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0-inline, 1-attachment',
  `hidemenu` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Hide document from menu',
  `alias_visible` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `typeidx` (`type`),
  KEY `aliasidx` (`alias`),
  KEY `parent` (`parent`),
  KEY `pub_unpub_published` (`pub_date`,`unpub_date`,`published`),
  KEY `pub_unpub` (`pub_date`,`unpub_date`),
  KEY `unpub` (`unpub_date`),
  KEY `pub` (`pub_date`),
  FULLTEXT KEY `content_ft_idx` (`pagetitle`,`description`,`content`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_content`
--

LOCK TABLES `evo_site_content` WRITE;
/*!40000 ALTER TABLE `evo_site_content` DISABLE KEYS */;
INSERT INTO `evo_site_content` VALUES
(1,'document','text/html','Главная','Космос Детейлинг Студия — детейлинг на Васильевском острове, СПб','Технологичный детейлинг на Васильевском острове: оклейка плёнкой PPF, полировка и керамика, тонировка, химчистка салона. Фиксированная смета, фото/видео-отчёт и гарантия результата. Кораблестроителей, 14.','index','',1,0,0,0,0,'','<h3>Install Successful!</h3>\n<p>You have successfully installed Evolution CMS (Community Edition).</p>\n\n<h3>Getting Help</h3>\n<p>The <a href=\"https://evo-cms.com/\" target=\"_blank\">Evolution CMS</a> site provides a great starting point to learn all things about Evolution CMS.</p>\n<p>Welcome to Evolution CMS!</p>\n',0,2,0,1,1,0,1781103138,1,1781103138,0,0,0,1781103138,1,'Главная',0,0,0,0,0,1),
(2,'document','text/html','Защита кузова','Оклейка авто плёнкой в СПб — PPF, винил, антихром | Космос Детейлинг','Бронирование кузова полиуретаном PPF, цветной и матовый винил, оклейка передней части, антихром, оклейка мото и брендирование. Васильевский остров, фиксированная смета и гарантия.','zashchita-kuzova','',1,0,0,0,0,NULL,NULL,0,3,1,1,1,0,1781103138,0,1781103138,0,0,0,1781103138,0,'Защита кузова',0,0,0,0,0,1),
(3,'document','text/html','Полировка и керамика','Полировка кузова и керамика в СПб | Космос Детейлинг на В.О.','Глубокая восстановительная полировка, керамическое покрытие и жидкое стекло, антидождь, покраска дисков. Васильевский остров, фиксированная смета, гарантия на керамику.','polirovka-keramika','',1,0,0,0,0,NULL,NULL,0,3,2,1,1,0,1781103138,0,1781103138,0,0,0,1781103138,0,'Полировка',0,0,0,0,0,1),
(4,'document','text/html','Тонировка и оптика','Тонировка авто и защита оптики в СПб | Космос Детейлинг','Тонировка стёкол по ГОСТ и атермальная, бронирование и шлифовка фар, защита лобового стекла плёнкой. Васильевский остров, аккуратно и с гарантией.','tonirovka-optika','',1,0,0,0,0,NULL,NULL,0,3,3,1,1,0,1781103138,0,1781103138,0,0,0,1781103138,0,'Тонировка',0,0,0,0,0,1),
(5,'document','text/html','Детейлинг салона','Детейлинг и химчистка салона авто в СПб | Космос Детейлинг','Глубокая химчистка салона, озонация, реставрация и перетяжка кожи, перешив потолка, интерьерный детейлинг. Васильевский остров. Гарантия сухого салона без запаха.','detailing-salona','',1,0,0,0,0,NULL,NULL,0,3,4,1,1,0,1781103138,0,1781103138,0,0,0,1781103138,0,'Салон',0,0,0,0,0,1),
(6,'document','text/html','Комфорт и оборудование','Шумоизоляция, доводчики, сигнализация и предпродажная подготовка авто в СПб','Шумоизоляция салона, установка доводчиков дверей и сигнализации, удаление вмятин без покраски (PDR), предпродажная подготовка. Васильевский остров, фиксированная смета.','komfort','',1,0,0,0,0,NULL,NULL,0,3,5,1,1,0,1781103138,0,1781103138,0,0,0,1781103138,0,'Комфорт',0,0,0,0,0,1),
(7,'document','text/html','Контакты','Контакты — Космос Детейлинг на Кораблестроителей, 14, СПб','Контакты детейлинг-студии Космос: Санкт-Петербург, Васильевский остров, ул. Кораблестроителей, 14. Телефон, WhatsApp, Telegram, карта проезда и онлайн-запись. Ежедневно 10:00–22:00.','kontakty','',1,0,0,0,0,NULL,NULL,0,4,6,1,1,0,1781103138,0,1781103138,0,0,0,1781103138,0,'Контакты',0,0,0,0,0,1),
(8,'document','text/xml','Карта сайта XML','','','sitemap.xml','',1,0,0,0,0,NULL,NULL,0,6,10,0,0,0,1781103138,0,1781103138,0,0,0,1781103138,0,'',0,0,0,0,1,1),
(9,'document','text/html','Страница не найдена','Страница не найдена — Космос Детейлинг','','404','',1,0,0,0,0,NULL,NULL,0,5,11,0,1,0,1781103138,0,1781103138,0,0,0,1781103138,0,'404',0,0,0,0,1,1),
(10,'document','text/plain','robots.txt','','','robots.txt','',1,0,0,0,0,'','User-agent: *\nAllow: /\nDisallow: /manager/\nDisallow: /assets/photos/\n\nSitemap: http://78.24.220.193/sitemap.xml\n',0,7,0,0,1,1,1781135108,1,1781135108,0,0,0,1781135108,1,'robots.txt',0,0,0,0,1,1);
/*!40000 ALTER TABLE `evo_site_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_content_closure`
--

DROP TABLE IF EXISTS `evo_site_content_closure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_content_closure` (
  `closure_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ancestor` int(10) unsigned NOT NULL,
  `descendant` int(10) unsigned NOT NULL,
  `depth` int(10) unsigned NOT NULL,
  PRIMARY KEY (`closure_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_content_closure`
--

LOCK TABLES `evo_site_content_closure` WRITE;
/*!40000 ALTER TABLE `evo_site_content_closure` DISABLE KEYS */;
INSERT INTO `evo_site_content_closure` VALUES
(1,1,1,0);
/*!40000 ALTER TABLE `evo_site_content_closure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_htmlsnippets`
--

DROP TABLE IF EXISTS `evo_site_htmlsnippets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_htmlsnippets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT 'Chunk',
  `editor_type` int(11) NOT NULL DEFAULT 0 COMMENT '0-plain text,1-rich text,2-code editor',
  `editor_name` varchar(50) NOT NULL DEFAULT 'none',
  `category` int(11) NOT NULL DEFAULT 0 COMMENT 'category id',
  `cache_type` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Cache option',
  `snippet` mediumtext DEFAULT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `createdon` int(11) NOT NULL DEFAULT 0,
  `editedon` int(11) NOT NULL DEFAULT 0,
  `disabled` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Disables the snippet',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_htmlsnippets`
--

LOCK TABLES `evo_site_htmlsnippets` WRITE;
/*!40000 ALTER TABLE `evo_site_htmlsnippets` DISABLE KEYS */;
/*!40000 ALTER TABLE `evo_site_htmlsnippets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_leads`
--

DROP TABLE IF EXISTS `evo_site_leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_leads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone` varchar(32) NOT NULL,
  `car` varchar(150) NOT NULL DEFAULT '',
  `services` varchar(500) NOT NULL DEFAULT '',
  `booking` varchar(200) NOT NULL DEFAULT '',
  `source` varchar(200) NOT NULL DEFAULT '',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_leads`
--

LOCK TABLES `evo_site_leads` WRITE;
/*!40000 ALTER TABLE `evo_site_leads` DISABLE KEYS */;
/*!40000 ALTER TABLE `evo_site_leads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_module_access`
--

DROP TABLE IF EXISTS `evo_site_module_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_module_access` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` int(11) NOT NULL DEFAULT 0,
  `usergroup` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_module_access`
--

LOCK TABLES `evo_site_module_access` WRITE;
/*!40000 ALTER TABLE `evo_site_module_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `evo_site_module_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_module_depobj`
--

DROP TABLE IF EXISTS `evo_site_module_depobj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_module_depobj` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` int(11) NOT NULL DEFAULT 0,
  `resource` int(11) NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 0 COMMENT '10-chunks, 20-docs, 30-plugins, 40-snips, 50-tpls, 60-tvs',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_module_depobj`
--

LOCK TABLES `evo_site_module_depobj` WRITE;
/*!40000 ALTER TABLE `evo_site_module_depobj` DISABLE KEYS */;
INSERT INTO `evo_site_module_depobj` VALUES
(1,2,7,30);
/*!40000 ALTER TABLE `evo_site_module_depobj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_modules`
--

DROP TABLE IF EXISTS `evo_site_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '0',
  `editor_type` int(11) NOT NULL DEFAULT 0 COMMENT '0-plain text,1-rich text,2-code editor',
  `disabled` tinyint(1) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0 COMMENT 'category id',
  `wrap` tinyint(1) NOT NULL DEFAULT 0,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `icon` varchar(255) NOT NULL DEFAULT '' COMMENT 'url to module icon',
  `enable_resource` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'enables the resource file feature',
  `resourcefile` varchar(255) NOT NULL DEFAULT '' COMMENT 'a physical link to a resource file',
  `createdon` int(11) NOT NULL DEFAULT 0,
  `editedon` int(11) NOT NULL DEFAULT 0,
  `guid` varchar(32) DEFAULT '' COMMENT 'globally unique identifier',
  `enable_sharedparams` tinyint(1) NOT NULL DEFAULT 0,
  `properties` text DEFAULT NULL,
  `modulecode` mediumtext DEFAULT NULL COMMENT 'module boot up code',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_modules`
--

LOCK TABLES `evo_site_modules` WRITE;
/*!40000 ALTER TABLE `evo_site_modules` DISABLE KEYS */;
INSERT INTO `evo_site_modules` VALUES
(1,'Extras','<strong>0.1.3</strong> first repository for Evolution CMS',0,0,1,0,0,'',0,'',1781102932,1781102932,'store435243542tf542t5t',1,'','//AUTHORS: Bumkaka & Dmi3yy \r\ninclude_once(\'../assets/modules/store/core.php\');'),
(2,'ClientSettings','Настройки сайта',0,0,1,0,0,'',0,'',1781103138,1781103138,'clsee234523g354f542t5t',1,'&prefix=Prefix for settings;text;client_ &config_path=Path to configuration files;text;','require_once MODX_BASE_PATH . \'assets/modules/clientsettings/core/src/ClientSettings.php\';\n\nif (!$modx->hasPermission(\'exec_module\')) {\n    $modx->sendRedirect(\'index.php?a=106\');\n}\n\nif (!is_array($modx->event->params)) {\n    $modx->event->params = [];\n}\n\nif (!function_exists(\'renderFormElement\')) {\n    include_once MODX_MANAGER_PATH . \'includes/tmplvars.commands.inc.php\';\n    include_once MODX_MANAGER_PATH . \'includes/tmplvars.inc.php\';\n}\n\nif (isset($_REQUEST[\'stay\'])) {\n    $_SESSION[\'stay\'] = $_REQUEST[\'stay\'];\n} else if (isset($_SESSION[\'stay\'])) {\n    $_REQUEST[\'stay\'] = $_SESSION[\'stay\'];\n}\n\n(new ClientSettings($params))->processRequest();');
/*!40000 ALTER TABLE `evo_site_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_plugin_events`
--

DROP TABLE IF EXISTS `evo_site_plugin_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_plugin_events` (
  `pluginid` int(11) NOT NULL,
  `evtid` int(11) NOT NULL DEFAULT 0,
  `priority` int(11) NOT NULL DEFAULT 0 COMMENT 'determines plugin run order',
  PRIMARY KEY (`pluginid`,`evtid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_plugin_events`
--

LOCK TABLES `evo_site_plugin_events` WRITE;
/*!40000 ALTER TABLE `evo_site_plugin_events` DISABLE KEYS */;
INSERT INTO `evo_site_plugin_events` VALUES
(1,82,0),
(2,82,1),
(3,82,2),
(3,90,0),
(3,101,0),
(4,107,0),
(5,39,0),
(5,45,0),
(5,88,0),
(5,96,0),
(5,98,0),
(5,105,0),
(5,110,0),
(5,114,0),
(6,9,0),
(6,42,0),
(6,45,0),
(6,46,0),
(7,73,0);
/*!40000 ALTER TABLE `evo_site_plugin_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_plugins`
--

DROP TABLE IF EXISTS `evo_site_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT 'Plugin',
  `editor_type` int(11) NOT NULL DEFAULT 0 COMMENT '0-plain text,1-rich text,2-code editor',
  `category` int(11) NOT NULL DEFAULT 0 COMMENT 'category id',
  `cache_type` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Cache option',
  `plugincode` mediumtext DEFAULT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `properties` text DEFAULT NULL COMMENT 'Default Properties',
  `disabled` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Disables the plugin',
  `moduleguid` varchar(32) DEFAULT '' COMMENT 'GUID of module from which to import shared parameters',
  `createdon` int(11) NOT NULL DEFAULT 0,
  `editedon` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_plugins`
--

LOCK TABLES `evo_site_plugins` WRITE;
/*!40000 ALTER TABLE `evo_site_plugins` DISABLE KEYS */;
INSERT INTO `evo_site_plugins` VALUES
(1,'OutdatedExtrasCheck','<strong>1.4.6</strong> Check for Outdated critical extras not compatible with EVO 1.4.6',0,1,0,'require MODX_BASE_PATH . \'assets/plugins/extrascheck/OutdatedExtrasCheck.plugin.php\';\r\n',0,'{\"wdgVisibility\":[{\"label\":\"Show widget for:\",\"type\":\"menu\",\"value\":\"AdminOnly\",\"options\":\"All,AdminOnly,AdminExcluded,ThisRoleOnly,ThisUserOnly\",\"default\":\"AdminOnly\",\"desc\":\"\"}],\"ThisRole\":[{\"label\":\"Run only for this role:\",\"type\":\"string\",\"value\":\"\",\"default\":\"\",\"desc\":\"\"}],\"ThisUser\":[{\"label\":\"Run only for this user:\",\"type\":\"string\",\"value\":\"\",\"default\":\"\",\"desc\":\"\"}]}',0,'',1781102932,1781102932),
(2,'AboutEvoWidget','<strong>1.1.1</strong> displays useful links at the dashboardn',0,1,0,'require MODX_BASE_PATH.\'assets/plugins/aboutevo/plugin.aboutevo.php\';\r\n',0,'{\"col_lg\":[{\"label\":\"Widget width\",\"type\":\"list\",\"value\":\"6\",\"options\":\"1,2,3,4,5,6,7,8,9,10,11,12\",\"default\":\"6\",\"desc\":\"\"}],\"menu_index\":[{\"label\":\"Output position\",\"type\":\"text\",\"value\":\"11\",\"default\":\"11\",\"desc\":\"\"}],\"hide_menu\":[{\"label\":\"Hide\",\"type\":\"list\",\"value\":\"0\",\"options\":\"0,1\",\"default\":\"0\",\"desc\":\"\"}]}',0,'',1781102932,1781102932),
(3,'Updater','<strong>0.9.2</strong> show message about outdated CMS version',0,1,0,'require MODX_BASE_PATH.\'assets/plugins/updater/plugin.updater.php\';\r\n',0,'{\"wdgVisibility\":[{\"label\":\"Show widget for:\",\"type\":\"menu\",\"value\":\"All\",\"options\":\"All,AdminOnly,AdminExcluded,ThisRoleOnly,ThisUserOnly\",\"default\":\"All\",\"desc\":\"\"}],\"ThisRole\":[{\"label\":\"Show only to this role id:\",\"type\":\"string\",\"value\":\"\",\"default\":\"\",\"desc\":\"\"}],\"ThisUser\":[{\"label\":\"Show only to this username:\",\"type\":\"string\",\"value\":\"\",\"default\":\"\",\"desc\":\"\"}],\"showButton\":[{\"label\":\"Show Update Button:\",\"type\":\"menu\",\"value\":\"AdminOnly\",\"options\":\"show,hide,AdminOnly\",\"default\":\"AdminOnly\",\"desc\":\"\"}]}',0,'',1781102932,1781102932),
(4,'TransAlias','<strong>1.0.4</strong> Human readible URL translation supporting multiple languages and overrides',0,1,0,'require MODX_BASE_PATH.\'assets/plugins/transalias/plugin.transalias.php\';',0,'{\"table_name\":[{\"label\":\"Trans table\",\"type\":\"list\",\"value\":\"russian\",\"options\":\"common,russian,dutch,german,czech,utf8,utf8lowercase\",\"default\":\"russian\",\"desc\":\"\"}],\"char_restrict\":[{\"label\":\"Restrict alias to\",\"type\":\"list\",\"value\":\"lowercase alphanumeric\",\"options\":\"lowercase alphanumeric,alphanumeric,legal characters\",\"default\":\"lowercase alphanumeric\",\"desc\":\"\"}],\"remove_periods\":[{\"label\":\"Remove Periods\",\"type\":\"list\",\"value\":\"No\",\"options\":\"Yes,No\",\"default\":\"No\",\"desc\":\"\"}],\"word_separator\":[{\"label\":\"Word Separator\",\"type\":\"list\",\"value\":\"dash\",\"options\":\"dash,underscore,none\",\"default\":\"dash\",\"desc\":\"\"}],\"override_tv\":[{\"label\":\"Override TV name\",\"type\":\"string\",\"value\":\"\",\"default\":\"\",\"desc\":\"\"}]}',0,'',1781102932,1781102932),
(5,'CodeMirror','<strong>1.7</strong> JavaScript library that can be used to create a relatively pleasant editor interface based on CodeMirror 5.33 (released on 21-12-2017)',0,1,0,'$_CM_BASE = \'assets/plugins/codemirror/\';\r\n\r\n$_CM_URL = MODX_SITE_URL . $_CM_BASE;\r\n\r\nrequire(MODX_BASE_PATH. $_CM_BASE .\'codemirror.plugin.php\');\r\n',0,'{\"theme\":[{\"label\":\"Theme\",\"type\":\"list\",\"value\":\"default\",\"options\":\"default,ambiance,blackboard,cobalt,eclipse,elegant,erlang-dark,lesser-dark,midnight,monokai,neat,night,one-dark,rubyblue,solarized,twilight,vibrant-ink,xq-dark,xq-light\",\"default\":\"default\",\"desc\":\"\"}],\"darktheme\":[{\"label\":\"Dark Theme\",\"type\":\"list\",\"value\":\"one-dark\",\"options\":\"default,ambiance,blackboard,cobalt,eclipse,elegant,erlang-dark,lesser-dark,midnight,monokai,neat,night,one-dark,rubyblue,solarized,twilight,vibrant-ink,xq-dark,xq-light\",\"default\":\"one-dark\",\"desc\":\"\"}],\"fontSize\":[{\"label\":\"Font-size\",\"type\":\"list\",\"value\":\"14\",\"options\":\"10,11,12,13,14,15,16,17,18\",\"default\":\"14\",\"desc\":\"\"}],\"lineHeight\":[{\"label\":\"Line-height\",\"type\":\"list\",\"value\":\"1.3\",\"options\":\"1,1.1,1.2,1.3,1.4,1.5\",\"default\":\"1.3\",\"desc\":\"\"}],\"indentUnit\":[{\"label\":\"Indent unit\",\"type\":\"int\",\"value\":\"4\",\"default\":\"4\",\"desc\":\"\"}],\"tabSize\":[{\"label\":\"The width of a tab character\",\"type\":\"int\",\"value\":\"4\",\"default\":\"4\",\"desc\":\"\"}],\"lineWrapping\":[{\"label\":\"lineWrapping\",\"type\":\"list\",\"value\":\"true\",\"options\":\"true,false\",\"default\":\"true\",\"desc\":\"\"}],\"matchBrackets\":[{\"label\":\"matchBrackets\",\"type\":\"list\",\"value\":\"true\",\"options\":\"true,false\",\"default\":\"true\",\"desc\":\"\"}],\"activeLine\":[{\"label\":\"activeLine\",\"type\":\"list\",\"value\":\"false\",\"options\":\"true,false\",\"default\":\"false\",\"desc\":\"\"}],\"emmet\":[{\"label\":\"emmet\",\"type\":\"list\",\"value\":\"true\",\"options\":\"true,false\",\"default\":\"true\",\"desc\":\"\"}],\"search\":[{\"label\":\"search\",\"type\":\"list\",\"value\":\"true\",\"options\":\"true,false\",\"default\":\"true\",\"desc\":\"\"}],\"indentWithTabs\":[{\"label\":\"indentWithTabs\",\"type\":\"list\",\"value\":\"true\",\"options\":\"true,false\",\"default\":\"true\",\"desc\":\"\"}],\"undoDepth\":[{\"label\":\"undoDepth\",\"type\":\"int\",\"value\":\"200\",\"default\":\"200\",\"desc\":\"\"}],\"historyEventDelay\":[{\"label\":\"historyEventDelay\",\"type\":\"int\",\"value\":\"1250\",\"default\":\"1250\",\"desc\":\"\"}]}',0,'',1781102932,1781102932),
(6,'PageBuilder','Конструктор блоков страницы',0,1,0,'/**\r\n * PageBuilder\r\n * \r\n * Creates form for manage content sections\r\n *\r\n * @category    plugin\r\n * @version     1.3.16\r\n * @author      mnoskov\r\n * @internal    @properties &tabName=Tab name;text;Page Builder &addType=Add type;menu;dropdown,icons,images;dropdown &placement=Placement;menu;content,tab;tab &order=Default container ordering;text;0\r\n * @internal    @events OnWebPageInit,OnManagerPageInit,OnDocFormRender,OnDocFormSave,OnBeforeEmptyTrash,OnDocDuplicate \r\n * @internal    @modx_category Manager and Admin\r\n * @internal    @installset base,sample\r\n */\r\n\r\ninclude_once MODX_BASE_PATH . \'assets/plugins/pagebuilder/pagebuilder.php\';\r\n\r\n$e = &$modx->event;\r\n\r\nswitch ($e->name) {\r\n    case \'OnWebPageInit\':\r\n    case \'OnManagerPageInit\': {\r\n        $modx->db->query(\"DELETE FROM \" . $modx->getFullTableName(\'site_plugin_events\') . \"\r\n            WHERE pluginid IN (\r\n               SELECT id\r\n               FROM \" . $modx->getFullTableName(\'site_plugins\') . \"\r\n               WHERE name = \'\" . $e->activePlugin . \"\'\r\n               AND disabled = 0\r\n            )\r\n            AND evtid IN (\r\n               SELECT id\r\n               FROM \" . $modx->getFullTableName(\'system_eventnames\') . \"\r\n               WHERE name IN (\'OnWebPageInit\', \'OnManagerPageInit\')\r\n            )\");\r\n\r\n        $modx->clearCache(\'full\');\r\n\r\n        (new PageBuilder($modx))->install();\r\n\r\n        return;\r\n    }\r\n\r\n    case \'OnDocFormRender\': {\r\n        $e->output((new PageBuilder($modx))->renderForm());\r\n        return;\r\n    }\r\n\r\n    case \'OnDocFormSave\': {\r\n        (new PageBuilder($modx))->save();\r\n        return;\r\n    }\r\n\r\n    case \'OnBeforeEmptyTrash\': {\r\n        (new PageBuilder($modx))->delete();\r\n        return;\r\n    }\r\n\r\n    case \'OnDocDuplicate\': {\r\n        (new PageBuilder($modx))->duplicate();\r\n        return;\r\n    }\r\n}',0,'{\r\n  \"tabName\": [\r\n    {\r\n      \"label\": \"Tab name\",\r\n      \"type\": \"text\",\r\n      \"value\": \"Конструктор\",\r\n      \"default\": \"Конструктор\",\r\n      \"desc\": \"\"\r\n    }\r\n  ],\r\n  \"addType\": [\r\n    {\r\n      \"label\": \"Add type\",\r\n      \"type\": \"menu\",\r\n      \"value\": \"dropdown\",\r\n      \"options\": \"dropdown,icons,images\",\r\n      \"default\": \"dropdown\",\r\n      \"desc\": \"\"\r\n    }\r\n  ],\r\n  \"placement\": [\r\n    {\r\n      \"label\": \"Placement\",\r\n      \"type\": \"menu\",\r\n      \"value\": \"tab\",\r\n      \"options\": \"content,tab\",\r\n      \"default\": \"content\",\r\n      \"desc\": \"\"\r\n    }\r\n  ],\r\n  \"order\": [\r\n    {\r\n      \"label\": \"Default container ordering\",\r\n      \"type\": \"text\",\r\n      \"value\": \"0\",\r\n      \"default\": \"0\",\r\n      \"desc\": \"\"\r\n    }\r\n  ]\r\n}',0,'',1781103138,1781121733),
(7,'ClientSettings','Пункт меню для модуля ClientSettings',0,1,0,'if ($modx->event->name == \'OnManagerMenuPrerender\'):\n	require_once MODX_BASE_PATH . \'assets/modules/clientsettings/core/src/ClientSettings.php\';\n	$cs   = new ClientSettings($params);\n	$mid  = $cs->getModuleId();\n	$lang = $cs->loadLang();\n	$tabs = $cs->loadStructure();\n	$permissionAccessInt = -1;\n	if($modx->hasPermission(\'exec_module\')):\n		// check if user has access permission, except admins\n		if($_SESSION[\'mgrRole\']!=1):\n			$rs = $modx->db->select(\n				\'sma.usergroup,mg.member\',\n				$modx->getFullTableName(\"site_module_access\") . \" sma LEFT JOIN \" . $modx->getFullTableName(\"member_groups\") . \" mg ON mg.user_group = sma.usergroup AND member=\'\" . $modx->getLoginUserID().\"\'\",\n				\"sma.module = \'{$mid}\'\"\n			);\n			//initialize permission to -1, if it stays -1 no permissions\n			//attached so permission granted\n			while ($row = $modx->db->getRow($rs)):\n				if($row[\"usergroup\"] && $row[\"member\"]):\n					//if there are permissions and this member has permission, ofcourse\n					//this is granted\n					$permissionAccessInt = 1;\n				elseif ($permissionAccessInt==-1):\n					//if there are permissions but this member has no permission and the\n					//variable was still in init state we set permission to 0; no permissions\n					$permissionAccessInt = 0;\n				endif;\n			endwhile;\n		else:\n			$permissionAccessInt = 1;\n		endif;\n		if($permissionAccessInt):\n			if (!empty($tabs)):\n				$menuparams = [\'client_settings\', \'main\', \'<i class=\"fa fa-cog\"></i>\' . $lang[\'cs.module_title\'], \'index.php?a=112&id=\' . $mid . \'&type=default\', $lang[\'cs.module_title\'], \'\', \'\', \'main\', 0, 100, \'\'];\n				if (count($tabs) > 1):\n					$menuparams[3] = \'javscript:;\';\n					$menuparams[5] = \'return false;\';\n					$sort = 0;\n					$params[\'menu\'][\'client_settings_main\'] = [\'client_settings_main\', \'client_settings\', \'<i class=\"fa fa-cog\"></i>\' . $lang[\'cs.module_title\'], \'index.php?a=112&id=\' . $mid . \'&type=default\', $lang[\'cs.module_title\'], \'\', \'\', \'main\', 0, $sort, \'\'];\n					foreach ($tabs as $alias => $item):\n						if ($alias != \'default\'):\n							$params[\'menu\'][\'client_settings_\' . $alias] = [\'client_settings_\' . $alias, \'client_settings\', \'<i class=\"fa \' . (isset($item[\'menu\'][\'icon\']) ? $item[\'menu\'][\'icon\'] : \'fa-cog\') . \'\"></i>\' . $item[\'menu\'][\'caption\'], \'index.php?a=112&id=\' . $mid . \'&type=\' . $alias, $item[\'menu\'][\'caption\'], \'\', \'\', \'main\', 0, $sort += 10, \'\'];\n						endif;\n					endforeach;\n				endif;\n				$params[\'menu\'][\'client_settings\'] = $menuparams;\n				$modx->event->output(serialize($params[\'menu\']));\n			endif;\n		endif;\n	endif;\n	return;\nendif;',0,NULL,0,'clsee234523g354f542t5t',1781103138,1781103138);
/*!40000 ALTER TABLE `evo_site_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_snippets`
--

DROP TABLE IF EXISTS `evo_site_snippets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_snippets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT 'Snippet',
  `editor_type` int(11) NOT NULL DEFAULT 0 COMMENT '0-plain text,1-rich text,2-code editor',
  `category` int(11) NOT NULL DEFAULT 0 COMMENT 'category id',
  `cache_type` int(11) NOT NULL DEFAULT 0 COMMENT 'Cache option',
  `snippet` mediumtext DEFAULT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `properties` text DEFAULT NULL COMMENT 'Default Properties',
  `moduleguid` varchar(32) NOT NULL DEFAULT '' COMMENT 'GUID of module from which to import shared parameters',
  `createdon` int(11) NOT NULL DEFAULT 0,
  `editedon` int(11) NOT NULL DEFAULT 0,
  `disabled` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Disables the snippet',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_snippets`
--

LOCK TABLES `evo_site_snippets` WRITE;
/*!40000 ALTER TABLE `evo_site_snippets` DISABLE KEYS */;
INSERT INTO `evo_site_snippets` VALUES
(1,'PageBuilder','Выводит блоки контента текущей страницы',0,1,0,'/**\n * PageBuilder\n * \n * output content sections for current page\n * \n * @version     1.3.16\n * @author      mnoskov\n * @category    snippet\n * @internal    @properties\n * @internal    @modx_category Content\n * @internal    @installset base,sample\n */\n \ninclude_once MODX_BASE_PATH . \'assets/plugins/pagebuilder/pagebuilder.php\';\nreturn (new PageBuilder($modx))->render($params);',0,NULL,'',1781103138,1781103138,0);
/*!40000 ALTER TABLE `evo_site_snippets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_templates`
--

DROP TABLE IF EXISTS `evo_site_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `templatename` varchar(100) NOT NULL DEFAULT '',
  `templatealias` varchar(100) NOT NULL DEFAULT '',
  `templatecontroller` varchar(100) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT 'Template',
  `editor_type` int(11) NOT NULL DEFAULT 0 COMMENT '0-plain text,1-rich text,2-code editor',
  `category` int(11) NOT NULL DEFAULT 0 COMMENT 'category id',
  `icon` varchar(255) NOT NULL DEFAULT '' COMMENT 'url to icon file',
  `template_type` int(11) NOT NULL DEFAULT 0 COMMENT '0-page,1-content',
  `content` mediumtext DEFAULT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `selectable` tinyint(1) NOT NULL DEFAULT 1,
  `createdon` int(11) NOT NULL DEFAULT 0,
  `editedon` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_templates`
--

LOCK TABLES `evo_site_templates` WRITE;
/*!40000 ALTER TABLE `evo_site_templates` DISABLE KEYS */;
INSERT INTO `evo_site_templates` VALUES
(1,'Minimal Template','','','Default minimal empty template (content returned only)',0,0,'',0,'[*content*]',0,1,0,0),
(2,'Главная страница','main','','Первый экран, направления, калькулятор, пакеты, портфолио',0,2,'',0,'',0,1,1781103138,1781103138),
(3,'Страница направления','cluster','','Кластерная страница услуг: hero, прайс, галерея, FAQ',0,2,'',0,'',0,1,1781103138,1781103138),
(4,'Контакты','contacts','','Контакты, карта, форма записи',0,2,'',0,'',0,1,1781103138,1781103138),
(5,'Текстовая страница','service','','Служебные и текстовые страницы (404 и т.п.)',0,2,'',0,'',0,1,1781103138,1781103138),
(6,'Sitemap XML','sitemap','','Карта сайта для поисковых систем',0,2,'',0,'',0,1,1781103138,1781103138),
(7,'Robots TXT','robots','','robots.txt (поле content ресурса)',0,0,'',0,'',0,1,1781135108,1781135108);
/*!40000 ALTER TABLE `evo_site_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_tmplvar_access`
--

DROP TABLE IF EXISTS `evo_site_tmplvar_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_tmplvar_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tmplvarid` int(11) NOT NULL DEFAULT 0,
  `documentgroup` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_tmplvar_access`
--

LOCK TABLES `evo_site_tmplvar_access` WRITE;
/*!40000 ALTER TABLE `evo_site_tmplvar_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `evo_site_tmplvar_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_tmplvar_contentvalues`
--

DROP TABLE IF EXISTS `evo_site_tmplvar_contentvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_tmplvar_contentvalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tmplvarid` int(11) NOT NULL DEFAULT 0 COMMENT 'Template Variable id',
  `contentid` int(11) NOT NULL DEFAULT 0 COMMENT 'Site Content Id',
  `value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_value_prefix` (`value`(50)),
  KEY `idx_tmplvarid_contentid_value` (`tmplvarid`,`contentid`,`value`(50)),
  KEY `idx_tmplvarid` (`tmplvarid`),
  KEY `idx_contentid` (`contentid`),
  KEY `idx_tmplvarid_contentid` (`tmplvarid`,`contentid`),
  FULLTEXT KEY `idx_value_ft` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_tmplvar_contentvalues`
--

LOCK TABLES `evo_site_tmplvar_contentvalues` WRITE;
/*!40000 ALTER TABLE `evo_site_tmplvar_contentvalues` DISABLE KEYS */;
INSERT INTO `evo_site_tmplvar_contentvalues` VALUES
(1,1,1,'детейлинг спб, детейлинг василеостровский, оклейка авто плёнкой, керамика авто, полировка кузова, химчистка салона, космос детейлинг'),
(2,2,1,'Космос Детейлинг Студия — премиальный детейлинг на В.О.'),
(3,3,1,'assets/img/work-004.jpg'),
(4,8,1,'1.0'),
(5,7,1,'weekly'),
(6,1,2,'оклейка авто плёнкой спб, ppf, бронирование авто, виниловая плёнка, антихром, оклейка передней части, оклейка мотоцикла'),
(7,2,2,'Защита кузова — PPF, винил, антихром | Космос Детейлинг'),
(8,3,2,'assets/img/work-049.jpg'),
(9,1,3,'полировка авто спб, керамика авто, нанокерамика, жидкое стекло, глубокая полировка, антидождь, покраска дисков'),
(10,2,3,'Полировка и керамика | Космос Детейлинг'),
(11,3,3,'assets/img/work-093.jpg'),
(12,1,4,'тонировка авто спб, атермальная тонировка, тонировка по гост, бронирование фар, шлифовка фар, защита лобового стекла'),
(13,2,4,'Тонировка и защита оптики | Космос Детейлинг'),
(14,3,4,'assets/img/work-097.jpg'),
(15,1,5,'химчистка салона авто спб, детейлинг салона, перетяжка салона, реставрация кожи, перешив потолка, озонация, перетяжка руля'),
(16,2,5,'Детейлинг и химчистка салона | Космос Детейлинг'),
(17,3,5,'assets/img/work-025.jpg'),
(18,1,6,'шумоизоляция авто спб, доводчики дверей, установка сигнализации, удаление вмятин без покраски, pdr, предпродажная подготовка авто'),
(19,2,6,'Комфорт, оборудование и предпродажная подготовка | Космос Детейлинг'),
(20,3,6,'assets/img/work-085.jpg'),
(21,1,7,'детейлинг кораблестроителей 14, детейлинг василеостровский контакты, космос детейлинг адрес, детейлинг намыв'),
(22,2,7,'Контакты — Космос Детейлинг Студия, СПб'),
(23,3,7,'assets/img/work-004.jpg'),
(24,4,9,'noindex,nofollow'),
(25,6,9,'1');
/*!40000 ALTER TABLE `evo_site_tmplvar_contentvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_tmplvar_templates`
--

DROP TABLE IF EXISTS `evo_site_tmplvar_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_tmplvar_templates` (
  `tmplvarid` int(11) NOT NULL DEFAULT 0 COMMENT 'Template Variable id',
  `templateid` int(11) NOT NULL DEFAULT 0,
  `rank` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tmplvarid`,`templateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_tmplvar_templates`
--

LOCK TABLES `evo_site_tmplvar_templates` WRITE;
/*!40000 ALTER TABLE `evo_site_tmplvar_templates` DISABLE KEYS */;
INSERT INTO `evo_site_tmplvar_templates` VALUES
(1,2,0),
(1,3,0),
(1,4,0),
(1,5,0),
(2,2,0),
(2,3,0),
(2,4,0),
(2,5,0),
(3,2,0),
(3,3,0),
(3,4,0),
(3,5,0),
(4,2,0),
(4,3,0),
(4,4,0),
(4,5,0),
(5,2,0),
(5,3,0),
(5,4,0),
(5,5,0),
(6,2,0),
(6,3,0),
(6,4,0),
(6,5,0),
(7,2,0),
(7,3,0),
(7,4,0),
(7,5,0),
(8,2,0),
(8,3,0),
(8,4,0),
(8,5,0);
/*!40000 ALTER TABLE `evo_site_tmplvar_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_site_tmplvars`
--

DROP TABLE IF EXISTS `evo_site_tmplvars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_site_tmplvars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `caption` varchar(80) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `editor_type` int(11) NOT NULL DEFAULT 0 COMMENT '0-plain text,1-rich text,2-code editor',
  `category` int(11) NOT NULL DEFAULT 0 COMMENT 'category id',
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `elements` text DEFAULT NULL,
  `rank` int(11) NOT NULL DEFAULT 0,
  `display` varchar(32) DEFAULT '' COMMENT 'Display Control',
  `display_params` text DEFAULT NULL COMMENT 'Display Control Properties',
  `default_text` text DEFAULT NULL,
  `createdon` int(11) NOT NULL DEFAULT 0,
  `editedon` int(11) NOT NULL DEFAULT 0,
  `properties` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indx_rank` (`rank`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_site_tmplvars`
--

LOCK TABLES `evo_site_tmplvars` WRITE;
/*!40000 ALTER TABLE `evo_site_tmplvars` DISABLE KEYS */;
INSERT INTO `evo_site_tmplvars` VALUES
(1,'text','seo_keywords','Meta keywords','Ключевые слова (meta keywords)',0,3,0,'',0,'',NULL,'',1781103138,1781103138,NULL),
(2,'text','og_title','OG: заголовок','Заголовок для соцсетей (og:title). Пусто — расширенный заголовок страницы',0,3,0,'',1,'',NULL,'',1781103138,1781103138,NULL),
(3,'image','og_image','OG: изображение','Картинка для соцсетей (og:image)',0,3,0,'',2,'',NULL,'',1781103138,1781103138,NULL),
(4,'dropdown','seo_robots','Meta robots','Индексация страницы',0,3,0,'По умолчанию==||index,follow==index,follow||noindex,nofollow==noindex,nofollow||noindex,follow==noindex,follow',3,'',NULL,'',1781103138,1781103138,NULL),
(5,'text','seo_canonical','Canonical URL','Канонический адрес. Пусто — адрес страницы',0,3,0,'',4,'',NULL,'',1781103138,1781103138,NULL),
(6,'checkbox','sitemap_exclude','Скрыть из sitemap','Не выводить страницу в sitemap.xml',0,3,0,'Да==1',5,'',NULL,'',1781103138,1781103138,NULL),
(7,'dropdown','sitemap_changefreq','Sitemap: частота','Частота изменения для sitemap.xml',0,3,0,'weekly==weekly||daily==daily||monthly==monthly||yearly==yearly',6,'',NULL,'weekly',1781103138,1781103138,NULL),
(8,'dropdown','sitemap_priority','Sitemap: приоритет','Приоритет страницы для sitemap.xml',0,3,0,'0.5==0.5||1.0==1.0||0.9==0.9||0.8==0.8||0.7==0.7||0.6==0.6||0.4==0.4||0.3==0.3',7,'',NULL,'0.8',1781103138,1781103138,NULL);
/*!40000 ALTER TABLE `evo_site_tmplvars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_system_eventnames`
--

DROP TABLE IF EXISTS `evo_system_eventnames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_system_eventnames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `service` int(11) NOT NULL DEFAULT 0 COMMENT 'System Service number',
  `groupname` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `system_eventnames_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_system_eventnames`
--

LOCK TABLES `evo_system_eventnames` WRITE;
/*!40000 ALTER TABLE `evo_system_eventnames` DISABLE KEYS */;
INSERT INTO `evo_system_eventnames` VALUES
(1,'OnAfterLoadDocumentObject',5,''),
(2,'OnAfterMoveDocument',1,'Documents'),
(3,'OnBeforeCacheUpdate',4,''),
(4,'OnBeforeChunkFormDelete',1,'Chunks'),
(5,'OnBeforeChunkFormSave',1,'Chunks'),
(6,'OnBeforeDocDuplicate',1,'Documents'),
(7,'OnBeforeDocFormDelete',1,'Documents'),
(8,'OnBeforeDocFormSave',1,'Documents'),
(9,'OnBeforeEmptyTrash',1,'Documents'),
(10,'OnBeforeFileBrowserCopy',1,'File Browser Events'),
(11,'OnBeforeFileBrowserDelete',1,'File Browser Events'),
(12,'OnBeforeFileBrowserMove',1,'File Browser Events'),
(13,'OnBeforeFileBrowserRename',1,'File Browser Events'),
(14,'OnBeforeFileBrowserUpload',1,'File Browser Events'),
(15,'OnBeforeLoadDocumentObject',5,''),
(16,'OnBeforeLoadExtension',5,''),
(17,'OnBeforeManagerPageInit',2,''),
(18,'OnBeforeMinifyCss',1,''),
(19,'OnBeforeModFormDelete',1,'Modules'),
(20,'OnBeforeModFormSave',1,'Modules'),
(21,'OnBeforeMoveDocument',1,'Documents'),
(22,'OnBeforeParseParams',5,''),
(23,'OnBeforePluginFormDelete',1,'Plugins'),
(24,'OnBeforePluginFormSave',1,'Plugins'),
(25,'OnBeforeSaveWebPageCache',4,''),
(26,'OnBeforeSnipFormDelete',1,'Snippets'),
(27,'OnBeforeSnipFormSave',1,'Snippets'),
(28,'OnBeforeTempFormDelete',1,'Templates'),
(29,'OnBeforeTempFormSave',1,'Templates'),
(30,'OnBeforeTVFormDelete',1,'Template Variables'),
(31,'OnBeforeTVFormSave',1,'Template Variables'),
(32,'OnBeforeUserDelete',1,'Users'),
(33,'OnBeforeUserLogin',1,'Users'),
(34,'OnBeforeUserLogout',1,'Users'),
(35,'OnBeforeUserSave',1,'Users'),
(36,'OnCacheUpdate',4,''),
(37,'OnChunkFormDelete',1,'Chunks'),
(38,'OnChunkFormPrerender',1,'Chunks'),
(39,'OnChunkFormRender',1,'Chunks'),
(40,'OnChunkFormSave',1,'Chunks'),
(41,'OnCreateDocGroup',1,'Documents'),
(42,'OnDocDuplicate',1,'Documents'),
(43,'OnDocFormDelete',1,'Documents'),
(44,'OnDocFormPrerender',1,'Documents'),
(45,'OnDocFormRender',1,'Documents'),
(46,'OnDocFormSave',1,'Documents'),
(47,'OnDocFormTemplateRender',1,'Documents'),
(48,'OnDocFormUnDelete',1,'Documents'),
(49,'OnDocPublished',5,''),
(50,'OnDocUnPublished',5,''),
(51,'OnEmptyTrash',1,'Documents'),
(52,'OnFileBrowserCopy',1,'File Browser Events'),
(53,'OnFileBrowserDelete',1,'File Browser Events'),
(54,'OnFileBrowserInit',1,'File Browser Events'),
(55,'OnFileBrowserMove',1,'File Browser Events'),
(56,'OnFileBrowserRename',1,'File Browser Events'),
(57,'OnFileBrowserUpload',1,'File Browser Events'),
(58,'OnFileManagerSettingsRender',1,'System Settings'),
(59,'OnFileManagerUpload',1,''),
(60,'OnFriendlyURLSettingsRender',1,'System Settings'),
(61,'OnInterfaceSettingsRender',1,'System Settings'),
(62,'OnLoadDocumentObject',5,''),
(63,'OnLoadSettings',1,'System Settings'),
(64,'OnLoadWebDocument',5,''),
(65,'OnLoadWebPageCache',4,''),
(66,'OnLogEvent',1,'Log Event'),
(67,'OnMakeDocUrl',5,''),
(68,'OnMakePageCacheKey',4,''),
(69,'OnManagerFrameLoader',2,''),
(70,'OnManagerLoginFormPrerender',2,''),
(71,'OnManagerLoginFormRender',2,''),
(72,'OnManagerMainFrameHeaderHTMLBlock',2,''),
(73,'OnManagerMenuPrerender',2,''),
(74,'OnManagerNodePrerender',2,''),
(75,'OnManagerNodeRender',2,''),
(76,'OnManagerPageInit',2,''),
(77,'OnManagerPreFrameLoader',2,''),
(78,'OnManagerTopPrerender',2,''),
(79,'OnManagerTreeInit',2,''),
(80,'OnManagerTreePrerender',2,''),
(81,'OnManagerTreeRender',2,''),
(82,'OnManagerWelcomeHome',2,''),
(83,'OnManagerWelcomePrerender',2,''),
(84,'OnManagerWelcomeRender',2,''),
(85,'OnMiscSettingsRender',1,'System Settings'),
(86,'OnModFormDelete',1,'Modules'),
(87,'OnModFormPrerender',1,'Modules'),
(88,'OnModFormRender',1,'Modules'),
(89,'OnModFormSave',1,'Modules'),
(90,'OnPageNotFound',1,''),
(91,'OnPageUnauthorized',1,''),
(92,'OnParseDocument',5,''),
(93,'OnParseProperties',5,''),
(94,'OnPluginFormDelete',1,'Plugins'),
(95,'OnPluginFormPrerender',1,'Plugins'),
(96,'OnPluginFormRender',1,'Plugins'),
(97,'OnPluginFormSave',1,'Plugins'),
(98,'OnRichTextEditorInit',1,'RichText Editor'),
(99,'OnRichTextEditorRegister',1,'RichText Editor'),
(100,'OnSecuritySettingsRender',1,'System Settings'),
(101,'OnSiteRefresh',1,''),
(102,'OnSiteSettingsRender',1,'System Settings'),
(103,'OnSnipFormDelete',1,'Snippets'),
(104,'OnSnipFormPrerender',1,'Snippets'),
(105,'OnSnipFormRender',1,'Snippets'),
(106,'OnSnipFormSave',1,'Snippets'),
(107,'OnStripAlias',1,'Documents'),
(108,'OnTempFormDelete',1,'Templates'),
(109,'OnTempFormPrerender',1,'Templates'),
(110,'OnTempFormRender',1,'Templates'),
(111,'OnTempFormSave',1,'Templates'),
(112,'OnTVFormDelete',1,'Template Variables'),
(113,'OnTVFormPrerender',1,'Template Variables'),
(114,'OnTVFormRender',1,'Template Variables'),
(115,'OnTVFormSave',1,'Template Variables'),
(116,'OnUserAuthentication',1,'Users'),
(117,'OnUserChangePassword',1,'Users'),
(118,'OnUserCreateGroup',1,'Users'),
(119,'OnUserDelete',1,'Users'),
(120,'OnUserFormPrerender',1,'Users'),
(121,'OnUserFormRender',1,'Users'),
(122,'OnUserLogin',1,'Users'),
(123,'OnUserLogout',1,'Users'),
(124,'OnUserSave',1,'Users'),
(125,'OnUserSettingsRender',1,'System Settings'),
(126,'OnWebPageComplete',5,''),
(127,'OnWebPageInit',5,''),
(128,'OnWebPagePrerender',5,''),
(129,'OnBeforeMailSend',1,''),
(130,'OnPBContainerRender',6,'PageBuilder'),
(131,'OnPBFieldRender',6,'PageBuilder'),
(132,'OnBeforeClientSettingsSave',6,'ClientSettings'),
(133,'OnClientSettingsSave',6,'ClientSettings');
/*!40000 ALTER TABLE `evo_system_eventnames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_system_settings`
--

DROP TABLE IF EXISTS `evo_system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_system_settings` (
  `setting_name` varchar(50) NOT NULL DEFAULT '',
  `setting_value` text DEFAULT NULL,
  PRIMARY KEY (`setting_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_system_settings`
--

LOCK TABLES `evo_system_settings` WRITE;
/*!40000 ALTER TABLE `evo_system_settings` DISABLE KEYS */;
INSERT INTO `evo_system_settings` VALUES
('alias_listing','1'),
('auto_menuindex','1'),
('auto_template_logic','1'),
('automatic_alias','1'),
('blocked_minutes','60'),
('cache_type','2'),
('client_address_full','Санкт-Петербург, ул. Кораблестроителей, 14'),
('client_address_short','СПб, ул. Кораблестроителей, 14'),
('client_area_served','Санкт-Петербург, Василеостровский район'),
('client_brand_sub','detailing studio'),
('client_brand_top','КОСМОС'),
('client_closes','22:00'),
('client_copyright','Космос Детейлинг Студия · Санкт-Петербург'),
('client_email','Kosmos-detai@yandex.ru'),
('client_footer_about','Премиальный детейлинг на Васильевском острове. Фиксированная смета, фото/видео-отчёт и гарантия результата.'),
('client_footer_codes',''),
('client_geo_lat','59.9690'),
('client_geo_lon','30.2090'),
('client_header_codes',''),
('client_header_cta_link','#zayavka'),
('client_header_cta_text','Рассчитать'),
('client_header_cta_text_long','Рассчитать стоимость'),
('client_lead_email','Kosmos-detai@yandex.ru'),
('client_lead_telegram_chat',''),
('client_lead_telegram_token',''),
('client_map_embed','https://yandex.ru/map-widget/v1/?ll=30.209%2C59.969&z=15&mode=search&text=%D0%A1%D0%B0%D0%BD%D0%BA%D1%82-%D0%9F%D0%B5%D1%82%D0%B5%D1%80%D0%B1%D1%83%D1%80%D0%B3%2C%20%D1%83%D0%BB%D0%B8%D1%86%D0%B0%20%D0%9A%D0%BE%D1%80%D0%B0%D0%B1%D0%BB%D0%B5%D1%81%D1%82%D1%80%D0%BE%D0%B8%D1%82%D0%B5%D0%BB%D0%B5%D0%B9%2C%2014'),
('client_og_image_default','assets/img/work-004.jpg'),
('client_opens','10:00'),
('client_org_name','Космос Детейлинг Студия'),
('client_phone','+79310000000'),
('client_phone_display','+7 (931) 000-00-00'),
('client_postal_code','199397'),
('client_price_range','₽₽₽'),
('client_privacy_link','#'),
('client_street','ул. Кораблестроителей, 14'),
('client_telegram','https://t.me/kosmos_detail'),
('client_vk',''),
('client_whatsapp','https://wa.me/79310000000'),
('client_worktime','Ежедневно 10:00 – 22:00'),
('client_worktime_full','Ежедневно, 10:00 – 22:00 · по записи'),
('datetime_format','dd-mm-YYYY'),
('default_template','3'),
('editor_css_path',''),
('editor_css_selectors',''),
('email_sender_method','1'),
('emailsender','Kosmos-detai@yandex.ru'),
('enable_bindings','1'),
('error_page','9'),
('failed_login_attempts','3'),
('fck_editor_autolang','0'),
('fck_editor_toolbar','standard'),
('fe_editor_lang','ru'),
('friendly_alias_urls','1'),
('friendly_url_suffix','.html'),
('friendly_urls','1'),
('group_tvs','5'),
('manager_direction','ltr'),
('manager_language','ru'),
('manager_layout','4'),
('modx_charset','UTF-8'),
('number_of_results','30'),
('old_template',''),
('publish_default','1'),
('remember_last_tab','1'),
('seostrict','1'),
('server_offset_time','0'),
('session.cookie.lifetime','604800'),
('settings_version',''),
('show_fullscreen_btn','0'),
('show_newresource_btn','0'),
('show_picker','0'),
('site_name','Космос Детейлинг Студия'),
('site_start','1'),
('site_status','1'),
('site_url','http://78.24.220.193/'),
('smtp_autotls','0'),
('theme_refresher',''),
('unauthorized_page','9'),
('upload_maxsize','10485760'),
('use_alias_path','1'),
('use_browser','1'),
('use_captcha','0'),
('use_editor','1'),
('warning_visibility','0'),
('xhtml_urls','0');
/*!40000 ALTER TABLE `evo_system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_user_attributes`
--

DROP TABLE IF EXISTS `evo_user_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_user_attributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `internalKey` int(11) NOT NULL DEFAULT 0,
  `fullname` varchar(255) NOT NULL DEFAULT '',
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `role` int(11) NOT NULL DEFAULT 0,
  `email` varchar(100) NOT NULL DEFAULT '',
  `phone` varchar(100) NOT NULL DEFAULT '',
  `mobilephone` varchar(100) NOT NULL DEFAULT '',
  `blocked` int(11) NOT NULL DEFAULT 0,
  `blockeduntil` int(11) NOT NULL DEFAULT 0,
  `blockedafter` int(11) NOT NULL DEFAULT 0,
  `logincount` int(11) NOT NULL DEFAULT 0,
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `thislogin` int(11) NOT NULL DEFAULT 0,
  `failedlogincount` int(11) NOT NULL DEFAULT 0,
  `sessionid` varchar(100) NOT NULL DEFAULT '',
  `dob` int(11) DEFAULT 0,
  `gender` int(11) NOT NULL DEFAULT 0 COMMENT '0 - unknown, 1 - Male 2 - female',
  `country` varchar(25) NOT NULL DEFAULT '',
  `street` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(25) NOT NULL DEFAULT '',
  `zip` varchar(25) NOT NULL DEFAULT '',
  `fax` varchar(100) NOT NULL DEFAULT '',
  `photo` varchar(255) NOT NULL DEFAULT '' COMMENT 'link to photo',
  `comment` text DEFAULT NULL,
  `createdon` int(11) NOT NULL DEFAULT 0,
  `editedon` int(11) NOT NULL DEFAULT 0,
  `verified` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `web_user_attributes_internalkey_index` (`internalKey`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_user_attributes`
--

LOCK TABLES `evo_user_attributes` WRITE;
/*!40000 ALTER TABLE `evo_user_attributes` DISABLE KEYS */;
INSERT INTO `evo_user_attributes` VALUES
(1,1,'',NULL,NULL,NULL,1,'info@kosmos-detail.ru','','',0,0,0,4,1781187582,1781187582,0,'1',0,0,'','','','','','','',NULL,1781102932,1781187582,1);
/*!40000 ALTER TABLE `evo_user_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_user_role_vars`
--

DROP TABLE IF EXISTS `evo_user_role_vars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_user_role_vars` (
  `tmplvarid` int(11) NOT NULL DEFAULT 0,
  `roleid` int(11) NOT NULL DEFAULT 0,
  `rank` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`tmplvarid`,`roleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_user_role_vars`
--

LOCK TABLES `evo_user_role_vars` WRITE;
/*!40000 ALTER TABLE `evo_user_role_vars` DISABLE KEYS */;
/*!40000 ALTER TABLE `evo_user_role_vars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_user_roles`
--

DROP TABLE IF EXISTS `evo_user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_user_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_user_roles`
--

LOCK TABLES `evo_user_roles` WRITE;
/*!40000 ALTER TABLE `evo_user_roles` DISABLE KEYS */;
INSERT INTO `evo_user_roles` VALUES
(1,'Administrator','Site administrators have full access to all functions'),
(2,'Editor','Limited to managing content'),
(3,'Publisher','Editor with expanded permissions including manage users, update Elements and site settings');
/*!40000 ALTER TABLE `evo_user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_user_settings`
--

DROP TABLE IF EXISTS `evo_user_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_user_settings` (
  `user` int(11) NOT NULL,
  `setting_name` varchar(50) NOT NULL DEFAULT '',
  `setting_value` text DEFAULT NULL,
  PRIMARY KEY (`user`,`setting_name`),
  KEY `user_settings_user_index` (`user`),
  KEY `setting_name` (`setting_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_user_settings`
--

LOCK TABLES `evo_user_settings` WRITE;
/*!40000 ALTER TABLE `evo_user_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `evo_user_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_user_values`
--

DROP TABLE IF EXISTS `evo_user_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_user_values` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tmplvarid` int(11) NOT NULL DEFAULT 0,
  `userid` int(11) NOT NULL DEFAULT 0,
  `value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_values_tmplvarid_userid_unique` (`tmplvarid`,`userid`),
  KEY `user_values_tmplvarid_index` (`tmplvarid`),
  KEY `user_values_userid_index` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_user_values`
--

LOCK TABLES `evo_user_values` WRITE;
/*!40000 ALTER TABLE `evo_user_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `evo_user_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evo_users`
--

DROP TABLE IF EXISTS `evo_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `evo_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `cachepwd` varchar(100) NOT NULL DEFAULT '' COMMENT 'Store new unconfirmed password',
  `refresh_token` varchar(255) DEFAULT NULL,
  `access_token` varchar(255) DEFAULT NULL,
  `valid_to` timestamp NULL DEFAULT NULL,
  `verified_key` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `web_users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evo_users`
--

LOCK TABLES `evo_users` WRITE;
/*!40000 ALTER TABLE `evo_users` DISABLE KEYS */;
INSERT INTO `evo_users` VALUES
(1,'admin','$P$Bjv4.YVehLxESJ.QA7FEFaigXc/zI1.','','dbc98a03acf0ba66054c6d9c6770e2b613b6d4e0ecb7a9f086eaa41061dbeb4c','b93dcef02f147711f421b23da2928409c0de30233e8c60dc72082daeb8fbd861','2026-06-11 22:19:42',NULL);
/*!40000 ALTER TABLE `evo_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'kosmos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-11 23:01:39
